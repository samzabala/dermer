<?php 
	
	/* Template Name: Home */
	
	get_header(); ?>



<?php get_template_part( 'homepage_template_parts/section', '1' );?>
<?php get_template_part( 'homepage_template_parts/section', '2' );?>
<?php get_template_part( 'homepage_template_parts/section', '3' );?>
<?php get_template_part( 'homepage_template_parts/section', '4' );?>
<?php get_template_part( 'homepage_template_parts/section', '5' );?>
<?php get_template_part( 'homepage_template_parts/section', '6' );?>
<?php get_template_part( 'homepage_template_parts/section', '7' );?>
<?php get_template_part( 'homepage_template_parts/section', '8' );?>


<?php get_footer(); ?>
