# WordPress MySQL database migration
#
# Generated: Wednesday 1. August 2018 22:44 UTC
# Hostname: localhost
# Database: `dermer`
# URL: //dermer.com
# Path: /Applications/MAMP/htdocs/dermer
# Tables: wp_commentmeta, wp_comments, wp_gf_draft_submissions, wp_gf_entry, wp_gf_entry_meta, wp_gf_entry_notes, wp_gf_form, wp_gf_form_meta, wp_gf_form_view, wp_links, wp_options, wp_postmeta, wp_posts, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users
# Table Prefix: wp_
# Post Types: revision, acf-field, acf-field-group, attachment, nav_menu_item, page, post
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2018-07-16 15:50:39', '2018-07-16 15:50:39', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href="https://gravatar.com">Gravatar</a>.', 0, 'post-trashed', '', '', 0, 0) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_gf_draft_submissions`
#

DROP TABLE IF EXISTS `wp_gf_draft_submissions`;


#
# Table structure of table `wp_gf_draft_submissions`
#

CREATE TABLE `wp_gf_draft_submissions` (
  `uuid` char(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `form_id` mediumint(8) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` varchar(39) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `source_url` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `submission` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `form_id` (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_gf_draft_submissions`
#

#
# End of data contents of table `wp_gf_draft_submissions`
# --------------------------------------------------------



#
# Delete any existing table `wp_gf_entry`
#

DROP TABLE IF EXISTS `wp_gf_entry`;


#
# Table structure of table `wp_gf_entry`
#

CREATE TABLE `wp_gf_entry` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `post_id` bigint(20) unsigned DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime DEFAULT NULL,
  `is_starred` tinyint(1) NOT NULL DEFAULT '0',
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `ip` varchar(39) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `source_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_agent` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `currency` varchar(5) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `payment_status` varchar(15) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `payment_date` datetime DEFAULT NULL,
  `payment_amount` decimal(19,2) DEFAULT NULL,
  `payment_method` varchar(30) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `transaction_id` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `is_fulfilled` tinyint(1) DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `transaction_type` tinyint(1) DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'active',
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `form_id_status` (`form_id`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_gf_entry`
#

#
# End of data contents of table `wp_gf_entry`
# --------------------------------------------------------



#
# Delete any existing table `wp_gf_entry_meta`
#

DROP TABLE IF EXISTS `wp_gf_entry_meta`;


#
# Table structure of table `wp_gf_entry_meta`
#

CREATE TABLE `wp_gf_entry_meta` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `entry_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`),
  KEY `meta_key` (`meta_key`(191)),
  KEY `entry_id` (`entry_id`),
  KEY `meta_value` (`meta_value`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_gf_entry_meta`
#

#
# End of data contents of table `wp_gf_entry_meta`
# --------------------------------------------------------



#
# Delete any existing table `wp_gf_entry_notes`
#

DROP TABLE IF EXISTS `wp_gf_entry_notes`;


#
# Table structure of table `wp_gf_entry_notes`
#

CREATE TABLE `wp_gf_entry_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_id` int(10) unsigned NOT NULL,
  `user_name` varchar(250) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_520_ci,
  `note_type` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `sub_type` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entry_id` (`entry_id`),
  KEY `entry_user_key` (`entry_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_gf_entry_notes`
#

#
# End of data contents of table `wp_gf_entry_notes`
# --------------------------------------------------------



#
# Delete any existing table `wp_gf_form`
#

DROP TABLE IF EXISTS `wp_gf_form`;


#
# Table structure of table `wp_gf_form`
#

CREATE TABLE `wp_gf_form` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_trash` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_gf_form`
#
INSERT INTO `wp_gf_form` ( `id`, `title`, `date_created`, `date_updated`, `is_active`, `is_trash`) VALUES
(1, 'Free Consultation', '2018-07-29 22:04:26', NULL, 1, 0),
(2, 'Free Consultation from Nav', '2018-07-30 03:10:04', NULL, 1, 0),
(3, 'Free Consultation Sidebar', '2018-07-30 20:38:41', NULL, 1, 0) ;

#
# End of data contents of table `wp_gf_form`
# --------------------------------------------------------



#
# Delete any existing table `wp_gf_form_meta`
#

DROP TABLE IF EXISTS `wp_gf_form_meta`;


#
# Table structure of table `wp_gf_form_meta`
#

CREATE TABLE `wp_gf_form_meta` (
  `form_id` mediumint(8) unsigned NOT NULL,
  `display_meta` longtext COLLATE utf8mb4_unicode_520_ci,
  `entries_grid_meta` longtext COLLATE utf8mb4_unicode_520_ci,
  `confirmations` longtext COLLATE utf8mb4_unicode_520_ci,
  `notifications` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_gf_form_meta`
#
INSERT INTO `wp_gf_form_meta` ( `form_id`, `display_meta`, `entries_grid_meta`, `confirmations`, `notifications`) VALUES
(1, '{"title":"Free Consultation","description":"","labelPlacement":"top_label","descriptionPlacement":"below","button":{"type":"text","text":"Submit","imageUrl":""},"fields":[{"type":"text","id":1,"label":"First Name","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","visibility":"visible","inputs":null,"formId":1,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"First Name","cssClass":"","inputName":"","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","enablePasswordInput":"","maxLength":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1,"displayOnly":""},{"type":"text","id":2,"label":"Last Name","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","visibility":"visible","inputs":null,"formId":1,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Last Name","cssClass":"","inputName":"","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","enablePasswordInput":"","maxLength":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1,"displayOnly":""},{"type":"phone","id":3,"label":"Phone","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","visibility":"visible","inputs":null,"phoneFormat":"standard","formId":1,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Phone","cssClass":"","inputName":"","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","form_id":"","productField":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1,"displayOnly":""},{"type":"email","id":4,"label":"Email","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","visibility":"visible","inputs":null,"formId":1,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Email","cssClass":"","inputName":"","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","emailConfirmEnabled":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1,"displayOnly":""},{"type":"textarea","id":5,"label":"Describe Your Case","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","visibility":"visible","inputs":null,"formId":1,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Describe Your Case","cssClass":"","inputName":"","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","form_id":"","useRichTextEditor":false,"multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"pageNumber":1,"displayOnly":""}],"version":"2.3.2","id":1,"useCurrentUserAsAuthor":true,"postContentTemplateEnabled":false,"postTitleTemplateEnabled":false,"postTitleTemplate":"","postContentTemplate":"","lastPageButton":null,"pagination":null,"firstPageCssClass":null,"notifications":{"5b5e39eae93b6":{"id":"5b5e39eae93b6","to":"{admin_email}","name":"Admin Notification","event":"form_submission","toType":"email","subject":"New submission from {form_title}","message":"{all_fields}"}},"confirmations":{"5b5e39eae9df5":{"id":"5b5e39eae9df5","name":"Default Confirmation","isDefault":true,"type":"message","message":"Thanks for contacting us! We will get in touch with you shortly.","url":"","pageId":"","queryString":""}},"subLabelPlacement":"below","cssClass":"","enableHoneypot":true,"enableAnimation":false,"save":{"enabled":false,"button":{"type":"link","text":"Save and Continue Later"}},"limitEntries":false,"limitEntriesCount":"","limitEntriesPeriod":"","limitEntriesMessage":"","scheduleForm":false,"scheduleStart":"","scheduleStartHour":"","scheduleStartMinute":"","scheduleStartAmpm":"","scheduleEnd":"","scheduleEndHour":"","scheduleEndMinute":"","scheduleEndAmpm":"","schedulePendingMessage":"","scheduleMessage":"","requireLogin":false,"requireLoginMessage":""}', NULL, '{"5b5e39eae9df5":{"id":"5b5e39eae9df5","name":"Default Confirmation","isDefault":true,"type":"message","message":"Thanks for contacting us! We will get in touch with you shortly.","url":"","pageId":"","queryString":""}}', '{"5b5e39eae93b6":{"id":"5b5e39eae93b6","to":"{admin_email}","name":"Admin Notification","event":"form_submission","toType":"email","subject":"New submission from {form_title}","message":"{all_fields}"}}'),
(2, '{"title":"Free Consultation from Nav","description":"","labelPlacement":"top_label","descriptionPlacement":"below","button":{"type":"text","text":"Submit","imageUrl":""},"fields":[{"type":"text","id":1,"label":"First Name","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","visibility":"visible","inputs":null,"formId":2,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"First Name","cssClass":"","inputName":"","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","enablePasswordInput":"","maxLength":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1,"displayOnly":""},{"type":"text","id":2,"label":"Last Name","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","visibility":"visible","inputs":null,"formId":2,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Last Name","cssClass":"","inputName":"","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","enablePasswordInput":"","maxLength":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1,"displayOnly":""},{"type":"phone","id":3,"label":"Phone","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","visibility":"visible","inputs":null,"phoneFormat":"standard","formId":2,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Phone","cssClass":"","inputName":"","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","form_id":"","productField":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1,"displayOnly":""},{"type":"email","id":4,"label":"Email","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","visibility":"visible","inputs":null,"formId":2,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Email","cssClass":"","inputName":"","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","emailConfirmEnabled":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1,"displayOnly":""},{"type":"textarea","id":5,"label":"Describe Your Case","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","visibility":"visible","inputs":null,"formId":2,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Describe Your Case","cssClass":"","inputName":"","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","form_id":"","useRichTextEditor":false,"multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"pageNumber":1,"displayOnly":""}],"version":"2.3.2","id":2,"useCurrentUserAsAuthor":true,"postContentTemplateEnabled":false,"postTitleTemplateEnabled":false,"postTitleTemplate":"","postContentTemplate":"","lastPageButton":null,"pagination":null,"firstPageCssClass":null,"subLabelPlacement":"below","cssClass":"","enableHoneypot":true,"enableAnimation":false,"save":{"enabled":false,"button":{"type":"link","text":"Save and Continue Later"}},"limitEntries":false,"limitEntriesCount":"","limitEntriesPeriod":"","limitEntriesMessage":"","scheduleForm":false,"scheduleStart":"","scheduleStartHour":"","scheduleStartMinute":"","scheduleStartAmpm":"","scheduleEnd":"","scheduleEndHour":"","scheduleEndMinute":"","scheduleEndAmpm":"","schedulePendingMessage":"","scheduleMessage":"","requireLogin":false,"requireLoginMessage":"","notifications":{"5b5e39eae93b6":{"id":"5b5e39eae93b6","to":"{admin_email}","name":"Admin Notification","event":"form_submission","toType":"email","subject":"New submission from {form_title}","message":"{all_fields}"}},"confirmations":{"5b5e39eae9df5":{"id":"5b5e39eae9df5","name":"Default Confirmation","isDefault":true,"type":"message","message":"Thanks for contacting us! We will get in touch with you shortly.","url":"","pageId":"","queryString":""}}}', NULL, '{"5b5e39eae9df5":{"id":"5b5e39eae9df5","name":"Default Confirmation","isDefault":true,"type":"message","message":"Thanks for contacting us! We will get in touch with you shortly.","url":"","pageId":"","queryString":""}}', '{"5b5e39eae93b6":{"id":"5b5e39eae93b6","to":"{admin_email}","name":"Admin Notification","event":"form_submission","toType":"email","subject":"New submission from {form_title}","message":"{all_fields}"}}'),
(3, '{"title":"Free Consultation Sidebar","description":"","labelPlacement":"top_label","descriptionPlacement":"below","button":{"type":"text","text":"Submit","imageUrl":""},"fields":[{"type":"text","id":1,"label":"First Name","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","visibility":"visible","inputs":null,"formId":3,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"First Name","cssClass":"","inputName":"","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","enablePasswordInput":"","maxLength":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1,"displayOnly":""},{"type":"text","id":2,"label":"Last Name","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","visibility":"visible","inputs":null,"formId":3,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Last Name","cssClass":"","inputName":"","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","enablePasswordInput":"","maxLength":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1,"displayOnly":""},{"type":"phone","id":3,"label":"Phone","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","visibility":"visible","inputs":null,"phoneFormat":"standard","formId":3,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Phone","cssClass":"","inputName":"","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","form_id":"","productField":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1,"displayOnly":""},{"type":"email","id":4,"label":"Email","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","visibility":"visible","inputs":null,"formId":3,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Email","cssClass":"","inputName":"","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","emailConfirmEnabled":"","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"useRichTextEditor":false,"pageNumber":1,"displayOnly":""},{"type":"textarea","id":5,"label":"Describe Your Case","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","visibility":"visible","inputs":null,"formId":3,"description":"","allowsPrepopulate":false,"inputMask":false,"inputMaskValue":"","inputType":"","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Describe Your Case","cssClass":"","inputName":"","noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","productField":"","form_id":"","useRichTextEditor":false,"multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"pageNumber":1,"displayOnly":""}],"version":"2.3.3","id":3,"useCurrentUserAsAuthor":true,"postContentTemplateEnabled":false,"postTitleTemplateEnabled":false,"postTitleTemplate":"","postContentTemplate":"","lastPageButton":null,"pagination":null,"firstPageCssClass":null,"subLabelPlacement":"below","cssClass":"","enableHoneypot":true,"enableAnimation":false,"save":{"enabled":false,"button":{"type":"link","text":"Save and Continue Later"}},"limitEntries":false,"limitEntriesCount":"","limitEntriesPeriod":"","limitEntriesMessage":"","scheduleForm":false,"scheduleStart":"","scheduleStartHour":"","scheduleStartMinute":"","scheduleStartAmpm":"","scheduleEnd":"","scheduleEndHour":"","scheduleEndMinute":"","scheduleEndAmpm":"","schedulePendingMessage":"","scheduleMessage":"","requireLogin":false,"requireLoginMessage":"","notifications":{"5b5e39eae93b6":{"id":"5b5e39eae93b6","to":"{admin_email}","name":"Admin Notification","event":"form_submission","toType":"email","subject":"New submission from {form_title}","message":"{all_fields}"}},"confirmations":{"5b5e39eae9df5":{"id":"5b5e39eae9df5","name":"Default Confirmation","isDefault":true,"type":"message","message":"Thanks for contacting us! We will get in touch with you shortly.","url":"","pageId":"","queryString":""}}}', NULL, '{"5b5e39eae9df5":{"id":"5b5e39eae9df5","name":"Default Confirmation","isDefault":true,"type":"message","message":"Thanks for contacting us! We will get in touch with you shortly.","url":"","pageId":"","queryString":""}}', '{"5b5e39eae93b6":{"id":"5b5e39eae93b6","to":"{admin_email}","name":"Admin Notification","event":"form_submission","toType":"email","subject":"New submission from {form_title}","message":"{all_fields}"}}') ;

#
# End of data contents of table `wp_gf_form_meta`
# --------------------------------------------------------



#
# Delete any existing table `wp_gf_form_view`
#

DROP TABLE IF EXISTS `wp_gf_form_view`;


#
# Table structure of table `wp_gf_form_view`
#

CREATE TABLE `wp_gf_form_view` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` char(15) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `count` mediumint(8) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `date_created` (`date_created`),
  KEY `form_id` (`form_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_gf_form_view`
#
INSERT INTO `wp_gf_form_view` ( `id`, `form_id`, `date_created`, `ip`, `count`) VALUES
(1, 1, '2018-07-29 22:07:39', '', 392),
(2, 2, '2018-07-30 03:10:42', '', 381),
(3, 3, '2018-07-30 20:41:25', '', 193),
(4, 1, '2018-07-30 22:13:03', '', 228),
(5, 2, '2018-07-31 15:25:09', '', 224),
(6, 3, '2018-07-31 20:41:34', '', 37),
(7, 1, '2018-07-31 22:13:36', '', 253),
(8, 2, '2018-08-01 15:27:34', '', 282),
(9, 3, '2018-08-01 20:50:02', '', 46),
(10, 1, '2018-08-01 22:18:28', '', 46) ;

#
# End of data contents of table `wp_gf_form_view`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=490 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://dermer.com', 'yes'),
(2, 'home', 'http://dermer.com', 'yes'),
(3, 'blogname', 'Dermer Appel Ruder, LLC', 'yes'),
(4, 'blogdescription', '', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'garrett@1pointinteractive.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:91:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=6&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:58:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:68:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:88:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:64:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:53:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$";s:91:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$";s:85:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1";s:77:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:65:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]";s:61:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]";s:47:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:57:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:77:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:53:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]";s:51:"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]";s:38:"([0-9]{4})/comment-page-([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&cpage=$matches[2]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:5:{i:0;s:29:"gravityforms/gravityforms.php";i:1;s:41:"acf-theme-code-pro/acf_theme_code_pro.php";i:2;s:34:"advanced-custom-fields-pro/acf.php";i:3;s:38:"post-duplicator/m4c-postduplicator.php";i:4;s:39:"wp-migrate-db-pro/wp-migrate-db-pro.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'dermer', 'yes'),
(41, 'stylesheet', 'dermer', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '38590', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '0', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_text', 'a:0:{}', 'yes'),
(80, 'widget_rss', 'a:0:{}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '0', 'yes'),
(84, 'page_on_front', '6', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'wp_page_for_privacy_policy', '3', 'yes'),
(92, 'initial_db_version', '38590', 'yes'),
(93, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(94, 'fresh_site', '0', 'yes'),
(95, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(96, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(99, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(100, 'sidebars_widgets', 'a:5:{s:19:"wp_inactive_widgets";a:0:{}s:7:"sidebar";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:16:"category_sidebar";a:0:{}s:15:"archive_sidebar";a:0:{}s:13:"array_version";i:3;}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(102, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(103, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(104, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(106, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(107, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(110, 'cron', 'a:6:{i:1533163840;a:1:{s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1533181840;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1533225049;a:2:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1533225301;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1533247426;a:1:{s:17:"gravityforms_cron";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(122, 'can_compress_scripts', '1', 'no'),
(133, 'theme_mods_twentyseventeen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1531756336;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes'),
(134, 'current_theme', '', 'yes'),
(135, 'theme_mods_dermer', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:2:{s:9:"main_menu";i:2;s:7:"pa_menu";i:3;}s:18:"custom_css_post_id";i:-1;}', 'yes'),
(136, 'theme_switched', '', 'yes'),
(140, 'WPLANG', '', 'yes'),
(141, 'new_admin_email', 'garrett@1pointinteractive.com', 'yes'),
(240, 'recently_activated', 'a:0:{}', 'yes'),
(242, 'rg_form_version', '2.3.3', 'yes'),
(243, 'gform_enable_background_updates', '1', 'yes'),
(244, 'gform_pending_installation', '', 'yes'),
(245, 'widget_gform_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(246, 'gravityformsaddon_gravityformswebapi_version', '1.0', 'yes'),
(247, 'gform_version_info', 'a:10:{s:12:"is_valid_key";b:1;s:6:"reason";s:0:"";s:7:"version";s:5:"2.3.3";s:3:"url";s:164:"http://s3.amazonaws.com/gravityforms/releases/gravityforms_2.3.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=X5NeqU3dqhv12uDXz1hNJBhGJL0%3D";s:15:"expiration_time";i:1538456400;s:9:"offerings";a:46:{s:12:"gravityforms";a:5:{s:12:"is_available";b:1;s:7:"version";s:5:"2.3.3";s:14:"version_latest";s:7:"2.3.3.2";s:3:"url";s:164:"http://s3.amazonaws.com/gravityforms/releases/gravityforms_2.3.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=X5NeqU3dqhv12uDXz1hNJBhGJL0%3D";s:10:"url_latest";s:166:"http://s3.amazonaws.com/gravityforms/releases/gravityforms_2.3.3.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=Q2csXcUCO45YnJtwhWULXln13ys%3D";}s:26:"gravityformsactivecampaign";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.4";s:14:"version_latest";s:5:"1.4.5";s:3:"url";s:189:"http://s3.amazonaws.com/gravityforms/addons/activecampaign/gravityformsactivecampaign_1.4.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=W7NrXIU2uRymr4wDnilenOWPd74%3D";s:10:"url_latest";s:195:"http://s3.amazonaws.com/gravityforms/addons/activecampaign/gravityformsactivecampaign_1.4.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=XsfvEs9u%2FnvwI%2BuTCNGjCHlvlbg%3D";}s:20:"gravityformsagilecrm";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.2";s:14:"version_latest";s:3:"1.2";s:3:"url";s:177:"http://s3.amazonaws.com/gravityforms/addons/agilecrm/gravityformsagilecrm_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=anEziOEgBPeVrj0TxBO1SI9Zopc%3D";s:10:"url_latest";s:177:"http://s3.amazonaws.com/gravityforms/addons/agilecrm/gravityformsagilecrm_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=anEziOEgBPeVrj0TxBO1SI9Zopc%3D";}s:24:"gravityformsauthorizenet";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"2.6";s:14:"version_latest";s:3:"2.6";s:3:"url";s:185:"http://s3.amazonaws.com/gravityforms/addons/authorizenet/gravityformsauthorizenet_2.6.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=Whw4CdIqyty3V4gDxsCsfCQ6ovY%3D";s:10:"url_latest";s:185:"http://s3.amazonaws.com/gravityforms/addons/authorizenet/gravityformsauthorizenet_2.6.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=Whw4CdIqyty3V4gDxsCsfCQ6ovY%3D";}s:18:"gravityformsaweber";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"2.7";s:14:"version_latest";s:5:"2.7.1";s:3:"url";s:175:"http://s3.amazonaws.com/gravityforms/addons/aweber/gravityformsaweber_2.7.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=VZbf5vagiSHeHT65gM%2BCQ9DUtLE%3D";s:10:"url_latest";s:179:"http://s3.amazonaws.com/gravityforms/addons/aweber/gravityformsaweber_2.7.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=1cHy%2F9juJzjHJbzRjK%2Fdc1F4CU4%3D";}s:21:"gravityformsbatchbook";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.3";s:14:"version_latest";s:3:"1.3";s:3:"url";s:181:"http://s3.amazonaws.com/gravityforms/addons/batchbook/gravityformsbatchbook_1.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=O7I1FZYHjHrOhdJ0B7b%2FH4YmpQ4%3D";s:10:"url_latest";s:181:"http://s3.amazonaws.com/gravityforms/addons/batchbook/gravityformsbatchbook_1.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=O7I1FZYHjHrOhdJ0B7b%2FH4YmpQ4%3D";}s:18:"gravityformsbreeze";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.3";s:14:"version_latest";s:3:"1.3";s:3:"url";s:175:"http://s3.amazonaws.com/gravityforms/addons/breeze/gravityformsbreeze_1.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=goZylE5O82JZn%2B5DTY3WcT6rhcw%3D";s:10:"url_latest";s:175:"http://s3.amazonaws.com/gravityforms/addons/breeze/gravityformsbreeze_1.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=goZylE5O82JZn%2B5DTY3WcT6rhcw%3D";}s:27:"gravityformscampaignmonitor";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"3.7";s:14:"version_latest";s:3:"3.7";s:3:"url";s:193:"http://s3.amazonaws.com/gravityforms/addons/campaignmonitor/gravityformscampaignmonitor_3.7.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=%2FMiinUWL3SX0EkknqCQipGs9j2Y%3D";s:10:"url_latest";s:193:"http://s3.amazonaws.com/gravityforms/addons/campaignmonitor/gravityformscampaignmonitor_3.7.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=%2FMiinUWL3SX0EkknqCQipGs9j2Y%3D";}s:20:"gravityformscampfire";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.1";s:14:"version_latest";s:5:"1.2.1";s:3:"url";s:181:"http://s3.amazonaws.com/gravityforms/addons/campfire/gravityformscampfire_1.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=Sl0%2F5qxfONFTQ%2BFieJY18R26oxk%3D";s:10:"url_latest";s:181:"http://s3.amazonaws.com/gravityforms/addons/campfire/gravityformscampfire_1.2.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=16f9nyjhKwz98WpNkcQR%2F0Gvqng%3D";}s:22:"gravityformscapsulecrm";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.3";s:14:"version_latest";s:3:"1.3";s:3:"url";s:181:"http://s3.amazonaws.com/gravityforms/addons/capsulecrm/gravityformscapsulecrm_1.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=pFhkgTrpkAUthprhZKZGw9t6m7E%3D";s:10:"url_latest";s:181:"http://s3.amazonaws.com/gravityforms/addons/capsulecrm/gravityformscapsulecrm_1.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=pFhkgTrpkAUthprhZKZGw9t6m7E%3D";}s:26:"gravityformschainedselects";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.0";s:14:"version_latest";s:5:"1.0.9";s:3:"url";s:195:"http://s3.amazonaws.com/gravityforms/addons/chainedselects/gravityformschainedselects_1.0.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=%2F4w7NT%2Bf8gR%2B87yxj7pQIrFqEXE%3D";s:10:"url_latest";s:193:"http://s3.amazonaws.com/gravityforms/addons/chainedselects/gravityformschainedselects_1.0.9.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=cA0ZMknyFA6u1n0p8cU0L09Q3%2BY%3D";}s:23:"gravityformscleverreach";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.4";s:14:"version_latest";s:3:"1.4";s:3:"url";s:183:"http://s3.amazonaws.com/gravityforms/addons/cleverreach/gravityformscleverreach_1.4.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=dldn2EQsPIJgrGH6ErtmpRGlu1U%3D";s:10:"url_latest";s:183:"http://s3.amazonaws.com/gravityforms/addons/cleverreach/gravityformscleverreach_1.4.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=dldn2EQsPIJgrGH6ErtmpRGlu1U%3D";}s:19:"gravityformscoupons";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"2.6";s:14:"version_latest";s:5:"2.6.2";s:3:"url";s:177:"http://s3.amazonaws.com/gravityforms/addons/coupons/gravityformscoupons_2.6.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=lcDbsHzMwrfywYzbmAPDx8T%2FEow%3D";s:10:"url_latest";s:179:"http://s3.amazonaws.com/gravityforms/addons/coupons/gravityformscoupons_2.6.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=6U0Q7dazmnmU5HjXy1n%2BSpOcQvA%3D";}s:17:"gravityformsdebug";a:5:{s:12:"is_available";b:1;s:7:"version";s:0:"";s:14:"version_latest";s:10:"1.0.beta10";s:3:"url";s:0:"";s:10:"url_latest";s:178:"http://s3.amazonaws.com/gravityforms/addons/debug/gravityformsdebug_1.0.beta10.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=ENtGV7hmdKgNJbrCM9WOJvQQweA%3D";}s:19:"gravityformsdropbox";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"2.1";s:14:"version_latest";s:5:"2.1.1";s:3:"url";s:175:"http://s3.amazonaws.com/gravityforms/addons/dropbox/gravityformsdropbox_2.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=wxMg1Xowo2l1nxpj3RTVSbQpbeE%3D";s:10:"url_latest";s:181:"http://s3.amazonaws.com/gravityforms/addons/dropbox/gravityformsdropbox_2.1.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=bpTz88VyLZlxKKbDl%2B%2Bn0RThho4%3D";}s:16:"gravityformsemma";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.2";s:14:"version_latest";s:5:"1.2.5";s:3:"url";s:171:"http://s3.amazonaws.com/gravityforms/addons/emma/gravityformsemma_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=fe3ow%2BpI6BWiuRSQlkdvPId0zRc%3D";s:10:"url_latest";s:171:"http://s3.amazonaws.com/gravityforms/addons/emma/gravityformsemma_1.2.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=3n0Dwx8AbQOjP8tTNvIXdE1EAzo%3D";}s:22:"gravityformsfreshbooks";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"2.5";s:14:"version_latest";s:5:"2.5.2";s:3:"url";s:185:"http://s3.amazonaws.com/gravityforms/addons/freshbooks/gravityformsfreshbooks_2.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=Q8pNeW9ZUif%2FsQ3zm852584Mg%2Bs%3D";s:10:"url_latest";s:183:"http://s3.amazonaws.com/gravityforms/addons/freshbooks/gravityformsfreshbooks_2.5.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=MF9HFPGYdfNzD99yTkloNRZodZ4%3D";}s:23:"gravityformsgetresponse";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.2";s:14:"version_latest";s:3:"1.2";s:3:"url";s:185:"http://s3.amazonaws.com/gravityforms/addons/getresponse/gravityformsgetresponse_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=mkQqKMfSOYUHC0uJDFTq%2BMMnfU0%3D";s:10:"url_latest";s:185:"http://s3.amazonaws.com/gravityforms/addons/getresponse/gravityformsgetresponse_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=mkQqKMfSOYUHC0uJDFTq%2BMMnfU0%3D";}s:21:"gravityformsgutenberg";a:5:{s:12:"is_available";b:1;s:7:"version";s:10:"1.0-beta-5";s:14:"version_latest";s:10:"1.0-beta-5";s:3:"url";s:186:"http://s3.amazonaws.com/gravityforms/addons/gutenberg/gravityformsgutenberg_1.0-beta-5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=xe8O2EuMo69Ew6uMtAg9slqHlAs%3D";s:10:"url_latest";s:186:"http://s3.amazonaws.com/gravityforms/addons/gutenberg/gravityformsgutenberg_1.0-beta-5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=xe8O2EuMo69Ew6uMtAg9slqHlAs%3D";}s:21:"gravityformshelpscout";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.5";s:14:"version_latest";s:3:"1.5";s:3:"url";s:181:"http://s3.amazonaws.com/gravityforms/addons/helpscout/gravityformshelpscout_1.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=ka8%2FErCda32cjZMCQCMc3rJhHLs%3D";s:10:"url_latest";s:181:"http://s3.amazonaws.com/gravityforms/addons/helpscout/gravityformshelpscout_1.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=ka8%2FErCda32cjZMCQCMc3rJhHLs%3D";}s:20:"gravityformshighrise";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.2";s:14:"version_latest";s:5:"1.2.3";s:3:"url";s:177:"http://s3.amazonaws.com/gravityforms/addons/highrise/gravityformshighrise_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=M2zvESoDQAsteP5e1ZAImRSuA2o%3D";s:10:"url_latest";s:179:"http://s3.amazonaws.com/gravityforms/addons/highrise/gravityformshighrise_1.2.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=aPlCnSMvqFCQZa1vyb23nH7XL6Q%3D";}s:19:"gravityformshipchat";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.2";s:14:"version_latest";s:3:"1.2";s:3:"url";s:175:"http://s3.amazonaws.com/gravityforms/addons/hipchat/gravityformshipchat_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=11Jt8JXPUdAHLUGpFcCFG24ycUY%3D";s:10:"url_latest";s:175:"http://s3.amazonaws.com/gravityforms/addons/hipchat/gravityformshipchat_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=11Jt8JXPUdAHLUGpFcCFG24ycUY%3D";}s:20:"gravityformsicontact";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.3";s:14:"version_latest";s:3:"1.3";s:3:"url";s:181:"http://s3.amazonaws.com/gravityforms/addons/icontact/gravityformsicontact_1.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=mxweyJkf%2FUJyGsCiCdA%2BTflhxsI%3D";s:10:"url_latest";s:181:"http://s3.amazonaws.com/gravityforms/addons/icontact/gravityformsicontact_1.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=mxweyJkf%2FUJyGsCiCdA%2BTflhxsI%3D";}s:19:"gravityformslogging";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.3";s:14:"version_latest";s:5:"1.3.1";s:3:"url";s:179:"http://s3.amazonaws.com/gravityforms/addons/logging/gravityformslogging_1.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=ewwj7u%2Bp%2B1Z0JyeVgxYjtJ2UYhc%3D";s:10:"url_latest";s:181:"http://s3.amazonaws.com/gravityforms/addons/logging/gravityformslogging_1.3.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=iBFP1L%2B6sOOaoEmBcyEPi6%2F6lF0%3D";}s:19:"gravityformsmadmimi";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.2";s:14:"version_latest";s:3:"1.2";s:3:"url";s:175:"http://s3.amazonaws.com/gravityforms/addons/madmimi/gravityformsmadmimi_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=C1PkNTWDqG8SDYTWc2LE6ThKSNk%3D";s:10:"url_latest";s:175:"http://s3.amazonaws.com/gravityforms/addons/madmimi/gravityformsmadmimi_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=C1PkNTWDqG8SDYTWc2LE6ThKSNk%3D";}s:21:"gravityformsmailchimp";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"4.3";s:14:"version_latest";s:3:"4.3";s:3:"url";s:181:"http://s3.amazonaws.com/gravityforms/addons/mailchimp/gravityformsmailchimp_4.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=fGugmEEPEmPVfr0kb%2B4Qcm6ma0Y%3D";s:10:"url_latest";s:181:"http://s3.amazonaws.com/gravityforms/addons/mailchimp/gravityformsmailchimp_4.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=fGugmEEPEmPVfr0kb%2B4Qcm6ma0Y%3D";}s:26:"gravityformspartialentries";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.2";s:14:"version_latest";s:5:"1.2.1";s:3:"url";s:191:"http://s3.amazonaws.com/gravityforms/addons/partialentries/gravityformspartialentries_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=czCmPYR%2F3OqTrwNNNr8tDeMrHY0%3D";s:10:"url_latest";s:191:"http://s3.amazonaws.com/gravityforms/addons/partialentries/gravityformspartialentries_1.2.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=bFpdg5J5fr1QWexmXhTQlFnwF20%3D";}s:18:"gravityformspaypal";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"3.1";s:14:"version_latest";s:5:"3.1.1";s:3:"url";s:173:"http://s3.amazonaws.com/gravityforms/addons/paypal/gravityformspaypal_3.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=izbUBjeRF9hEU0ETYjmlwxi5TyI%3D";s:10:"url_latest";s:175:"http://s3.amazonaws.com/gravityforms/addons/paypal/gravityformspaypal_3.1.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=w9IUdhsETHIXtHqtGUpPOJVGF5U%3D";}s:33:"gravityformspaypalexpresscheckout";a:3:{s:12:"is_available";b:0;s:7:"version";s:0:"";s:14:"version_latest";N;}s:29:"gravityformspaypalpaymentspro";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"2.3";s:14:"version_latest";s:5:"2.3.2";s:3:"url";s:195:"http://s3.amazonaws.com/gravityforms/addons/paypalpaymentspro/gravityformspaypalpaymentspro_2.3.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=vVGMkr3PhLjxvMO4nEcf4cOLBsU%3D";s:10:"url_latest";s:197:"http://s3.amazonaws.com/gravityforms/addons/paypalpaymentspro/gravityformspaypalpaymentspro_2.3.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=iLRmdxT16kGksdvjyklfyMrlFuQ%3D";}s:21:"gravityformspaypalpro";a:5:{s:12:"is_available";b:1;s:7:"version";s:5:"1.8.1";s:14:"version_latest";s:5:"1.8.1";s:3:"url";s:185:"http://s3.amazonaws.com/gravityforms/addons/paypalpro/gravityformspaypalpro_1.8.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=yOX%2B7kgyeKEDX%2FUxs7sZTeR7Ilg%3D";s:10:"url_latest";s:185:"http://s3.amazonaws.com/gravityforms/addons/paypalpro/gravityformspaypalpro_1.8.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=yOX%2B7kgyeKEDX%2FUxs7sZTeR7Ilg%3D";}s:20:"gravityformspicatcha";a:3:{s:12:"is_available";b:0;s:7:"version";s:3:"2.0";s:14:"version_latest";s:3:"2.0";}s:16:"gravityformspipe";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.1";s:14:"version_latest";s:3:"1.1";s:3:"url";s:169:"http://s3.amazonaws.com/gravityforms/addons/pipe/gravityformspipe_1.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=v8blOBfFXdsQBsfva4EVXuOYnDU%3D";s:10:"url_latest";s:169:"http://s3.amazonaws.com/gravityforms/addons/pipe/gravityformspipe_1.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=v8blOBfFXdsQBsfva4EVXuOYnDU%3D";}s:17:"gravityformspolls";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"3.1";s:14:"version_latest";s:5:"3.1.4";s:3:"url";s:177:"http://s3.amazonaws.com/gravityforms/addons/polls/gravityformspolls_3.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=ruGczTroWooc%2FKwi7f%2Bb9CNI8%2BQ%3D";s:10:"url_latest";s:175:"http://s3.amazonaws.com/gravityforms/addons/polls/gravityformspolls_3.1.4.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=3dAo154ZSI5q8J9vs4OenqGK%2Fts%3D";}s:16:"gravityformsquiz";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"3.1";s:14:"version_latest";s:5:"3.1.7";s:3:"url";s:171:"http://s3.amazonaws.com/gravityforms/addons/quiz/gravityformsquiz_3.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=YXQAyjs9FK1%2FpkgpgaQQWEWSioo%3D";s:10:"url_latest";s:173:"http://s3.amazonaws.com/gravityforms/addons/quiz/gravityformsquiz_3.1.7.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=njxrvBKyUO%2FSTXrbioVHONcwKeM%3D";}s:19:"gravityformsrestapi";a:5:{s:12:"is_available";b:1;s:7:"version";s:10:"2.0-beta-2";s:14:"version_latest";s:10:"2.0-beta-2";s:3:"url";s:184:"http://s3.amazonaws.com/gravityforms/addons/restapi/gravityformsrestapi_2.0-beta-2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=eh1YnxhN%2Ftc2zQnaiod1pJe0o9k%3D";s:10:"url_latest";s:184:"http://s3.amazonaws.com/gravityforms/addons/restapi/gravityformsrestapi_2.0-beta-2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=eh1YnxhN%2Ftc2zQnaiod1pJe0o9k%3D";}s:21:"gravityformssignature";a:5:{s:12:"is_available";b:1;s:7:"version";s:5:"3.5.1";s:14:"version_latest";s:5:"3.5.2";s:3:"url";s:187:"http://s3.amazonaws.com/gravityforms/addons/signature/gravityformssignature_3.5.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=6bL%2F6JY7h1uSq9HkVBDxH%2B%2Bf46s%3D";s:10:"url_latest";s:181:"http://s3.amazonaws.com/gravityforms/addons/signature/gravityformssignature_3.5.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=kIDZxbBe4PbJnokpHYLZhQXzsoY%3D";}s:17:"gravityformsslack";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.8";s:14:"version_latest";s:3:"1.8";s:3:"url";s:173:"http://s3.amazonaws.com/gravityforms/addons/slack/gravityformsslack_1.8.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=Hzif%2BX3zG0lDIbBeAff71nH7mxc%3D";s:10:"url_latest";s:173:"http://s3.amazonaws.com/gravityforms/addons/slack/gravityformsslack_1.8.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=Hzif%2BX3zG0lDIbBeAff71nH7mxc%3D";}s:18:"gravityformsstripe";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"2.5";s:14:"version_latest";s:5:"2.5.4";s:3:"url";s:173:"http://s3.amazonaws.com/gravityforms/addons/stripe/gravityformsstripe_2.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=ciMltNdIyu1PdA2JA6uBsIF7y8U%3D";s:10:"url_latest";s:181:"http://s3.amazonaws.com/gravityforms/addons/stripe/gravityformsstripe_2.5.4.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=GCeWHtdadXsiCjiZ%2B%2BFZYWcvc%2Fs%3D";}s:18:"gravityformssurvey";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"3.2";s:14:"version_latest";s:5:"3.2.2";s:3:"url";s:177:"http://s3.amazonaws.com/gravityforms/addons/survey/gravityformssurvey_3.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=NK5unUVVjZxr%2F%2BBOfOMnJ3GLWxc%3D";s:10:"url_latest";s:181:"http://s3.amazonaws.com/gravityforms/addons/survey/gravityformssurvey_3.2.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=45fiavYuwDJc%2F0l%2BTzFjJL76L%2F8%3D";}s:18:"gravityformstrello";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.2";s:14:"version_latest";s:5:"1.2.2";s:3:"url";s:177:"http://s3.amazonaws.com/gravityforms/addons/trello/gravityformstrello_1.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=ko%2FNt4ZLMoD5%2FOPA115CDCzgsRg%3D";s:10:"url_latest";s:179:"http://s3.amazonaws.com/gravityforms/addons/trello/gravityformstrello_1.2.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=qVm7QMQhkX3k3K%2FF%2BwVl09gZpe4%3D";}s:18:"gravityformstwilio";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"2.5";s:14:"version_latest";s:3:"2.5";s:3:"url";s:177:"http://s3.amazonaws.com/gravityforms/addons/twilio/gravityformstwilio_2.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=VQ7WRPoH99Ig%2BfuP%2BVtBshEC60c%3D";s:10:"url_latest";s:177:"http://s3.amazonaws.com/gravityforms/addons/twilio/gravityformstwilio_2.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=VQ7WRPoH99Ig%2BfuP%2BVtBshEC60c%3D";}s:28:"gravityformsuserregistration";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"3.9";s:14:"version_latest";s:5:"3.9.5";s:3:"url";s:195:"http://s3.amazonaws.com/gravityforms/addons/userregistration/gravityformsuserregistration_3.9.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=lBsEKTXOc1XCsIRa%2FreNFL4ojaI%3D";s:10:"url_latest";s:197:"http://s3.amazonaws.com/gravityforms/addons/userregistration/gravityformsuserregistration_3.9.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=uImNPIZmqSyYliCKreL%2Fm5jatMg%3D";}s:20:"gravityformswebhooks";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.1";s:14:"version_latest";s:5:"1.1.5";s:3:"url";s:177:"http://s3.amazonaws.com/gravityforms/addons/webhooks/gravityformswebhooks_1.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=oXxlH93Z6Ww5RPdkQoAELL5WwEQ%3D";s:10:"url_latest";s:183:"http://s3.amazonaws.com/gravityforms/addons/webhooks/gravityformswebhooks_1.1.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=F1el%2BnTWhxBq9EGh0FYp2599%2BGA%3D";}s:18:"gravityformszapier";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"3.0";s:14:"version_latest";s:5:"3.0.1";s:3:"url";s:173:"http://s3.amazonaws.com/gravityforms/addons/zapier/gravityformszapier_3.0.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=wNusos2h8Hn5r4wosp3euX5n1Jc%3D";s:10:"url_latest";s:175:"http://s3.amazonaws.com/gravityforms/addons/zapier/gravityformszapier_3.0.1.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=VfuXqr7SjC3Zl3VJF4nXtzrPkpk%3D";}s:19:"gravityformszohocrm";a:5:{s:12:"is_available";b:1;s:7:"version";s:3:"1.5";s:14:"version_latest";s:3:"1.5";s:3:"url";s:177:"http://s3.amazonaws.com/gravityforms/addons/zohocrm/gravityformszohocrm_1.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=JzcWWSNAE9HfP8ouxrhU79%2F0p8o%3D";s:10:"url_latest";s:177:"http://s3.amazonaws.com/gravityforms/addons/zohocrm/gravityformszohocrm_1.5.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=JzcWWSNAE9HfP8ouxrhU79%2F0p8o%3D";}}s:9:"is_active";s:1:"1";s:14:"version_latest";s:7:"2.3.3.2";s:10:"url_latest";s:166:"http://s3.amazonaws.com/gravityforms/releases/gravityforms_2.3.3.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1533307270&Signature=Q2csXcUCO45YnJtwhWULXln13ys%3D";s:9:"timestamp";i:1533134469;}', 'yes'),
(254, 'rg_gforms_key', '621e21584ab7936611e0d28422299c97', 'yes'),
(255, 'gf_site_key', 'fa215613-3c18-4ad2-819b-1195510316ed', 'yes'),
(256, 'gf_site_secret', '0c4d894d-c4ae-4b7a-894c-7740c197103c', 'yes'),
(257, 'rg_gforms_enable_akismet', '0', 'yes'),
(258, 'rg_gforms_currency', 'USD', 'yes'),
(259, 'gform_enable_toolbar_menu', '1', 'yes'),
(266, 'category_children', 'a:0:{}', 'yes'),
(273, 'rg_gforms_disable_css', '1', 'yes'),
(274, 'rg_gforms_captcha_public_key', '', 'yes'),
(275, 'rg_gforms_captcha_private_key', '', 'yes'),
(276, 'rg_gforms_message', '<!--GFM-->', 'yes'),
(309, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(330, 'gf_previous_db_version', '2.3.2', 'yes'),
(331, 'gf_upgrade_lock', '', 'yes'),
(332, 'gform_sticky_admin_messages', 'a:0:{}', 'yes'),
(334, 'gf_db_version', '2.3.3', 'yes'),
(339, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1533163456;}', 'no'),
(381, 'mtphr_post_duplicator_settings', '', 'yes'),
(445, 'acf_version', '5.6.10', 'yes'),
(448, 'acf_pro_license', 'YToyOntzOjM6ImtleSI7czo3MjoiYjNKa1pYSmZhV1E5TXpZd01EaDhkSGx3WlQxa1pYWmxiRzl3WlhKOFpHRjBaVDB5TURFMExUQTNMVEk0SURJd09qVXlPak0zIjtzOjM6InVybCI7czoxNzoiaHR0cDovL2Rlcm1lci5jb20iO30=', 'yes'),
(449, 'dd9b23a13775ccc12b5389d301f8ef5d', 'a:2:{s:7:"timeout";i:1533167912;s:5:"value";s:7062:"{"new_version":"2.3.0","stable_version":"2.3.0","name":"ACF Theme Code Pro","slug":"acf_theme_code_pro","url":"https:\\/\\/hookturn.io\\/downloads\\/acf-theme-code-pro\\/?changelog=1","last_updated":"2018-02-12 17:47:26","homepage":"https:\\/\\/hookturn.io\\/downloads\\/acf-theme-code-pro\\/","package":"","download_link":"","sections":{"description":"<p>Save time &amp; automatically generate the code required to implement Advanced Custom Fields in your themes!<br \\/>\\nACF Theme Code Pro is a premium add-on\\u00a0for the awesome\\u00a0<a href=\\"https:\\/\\/www.advancedcustomfields.com\\/pro\\/\\" target=\\"_blank\\" rel=\\"nofollow noopener noreferrer\\">Advanced Custom Fields Pro<\\/a>\\u00a0WordPress plugin.<\\/p>\\n<p>[ecquote]<\\/p>\\n<p>Whenever you publish, edit or update an ACF Field Group, the code required to implement your unique custom fields is conveniently displayed in a <strong>Theme Code<\\/strong> section right below the Field Group settings.<\\/p>\\n<p>Features<\\/p>\\n<ul>\\n<li>Clipboard icons to easily copy code blocks into your theme<\\/li>\\n<li>Field names and variables are automatically updated<\\/li>\\n<li>Code generated is based on the official ACF documentation<\\/li>\\n<li>Great for offline ACF documentation<\\/li>\\n<\\/ul>\\n<p>ACF Theme Code Pro generates code for the premium ACF fields:<\\/p>\\n<ul class=\\"two-up\\">\\n<li>Flexible content field<\\/li>\\n<li>Repeater field<\\/li>\\n<li>Gallery field<\\/li>\\n<li>Clone field<\\/li>\\n<li>Group field<\\/li>\\n<li>Link field<\\/li>\\n<li>Range field<\\/li>\\n<li>Button field<\\/li>\\n<\\/ul>\\n<p>ACF Theme Code Pro generates code for these 3rd Party fields:<\\/p>\\n<ul class=\\"two-up\\">\\n<li>Font Awesome field<\\/li>\\n<li>Google font selector field<\\/li>\\n<li>Image crop field<\\/li>\\n<li>Markdown field<\\/li>\\n<li>Nav Menu field<\\/li>\\n<li>RGBA Colour field<\\/li>\\n<li>Sidebar Selector field<\\/li>\\n<li>Smart Button field<\\/li>\\n<li>Table field<\\/li>\\n<li>TablePress field<\\/li>\\n<li>Address Field<\\/li>\\n<li>Number Slider Field<\\/li>\\n<li>Post Type Select Field<\\/li>\\n<li>Code Field<\\/li>\\n<li>Link Field<\\/li>\\n<li>Link Picker Field<\\/li>\\n<li>YouTube Picker Field<\\/li>\\n<li>Range Field<\\/li>\\n<li>Focal Point Field<\\/li>\\n<\\/ul>\\n<p>ACF Theme Code Pro generates the code for all standard ACF fields:<\\/p>\\n<ul class=\\"two-up\\">\\n<li>Text<\\/li>\\n<li>Text Area<\\/li>\\n<li>Number<\\/li>\\n<li>Email<\\/li>\\n<li>Password<\\/li>\\n<li>WYSIWYG<\\/li>\\n<li>File<\\/li>\\n<li>Image<\\/li>\\n<li>Select<\\/li>\\n<li>Checkbox<\\/li>\\n<li>Radio<\\/li>\\n<li>True \\/ False<\\/li>\\n<li>User<\\/li>\\n<li>Google Map<\\/li>\\n<li>Date Picker<\\/li>\\n<li>Date Time Picker<\\/li>\\n<li>Time Picker<\\/li>\\n<li>Color Picker<\\/li>\\n<li>Page Link<\\/li>\\n<li>Post Object<\\/li>\\n<li>Relationship<\\/li>\\n<li>Taxonomy<\\/li>\\n<li>oEmbed<\\/li>\\n<\\/ul>\\n<p>New in Version 2 : Location Rule Support<\\/p>\\n<p>ACF Theme Code Pro can generate code for multiple location rules on each field group, you\\u2019re using ACF Pro this includes locations\\u00a0like <strong>Options<\\/strong>, <strong>Users<\\/strong>, <strong>Widgets<\\/strong>, <strong>Comments<\\/strong>, <strong>Terms<\\/strong> and <strong>Attachments.<\\/strong><br \\/>\\nWorks best with:<\\/p>\\n<ul>\\n<li>Advanced Custom Fields\\u00a0Pro v5.6.8 or higher<\\/li>\\n<li>Advanced Custom Fields (Free) v4.4 or v5.0<\\/li>\\n<li>WordPress 4.9.4 or higher<\\/li>\\n<\\/ul>\\n<p>Current Pro Version<\\/p>\\n<ul>\\n<li>Version 2.3.0\\u00a0released in February 2018<\\/li>\\n<\\/ul>\\n<p>If you\'d like to \'try before you buy\' you can\\u00a0<a href=\\"https:\\/\\/wordpress.org\\/plugins\\/acf-theme-code\\/\\" target=\\"_blank\\" rel=\\"noopener noreferrer\\">check out our free version<\\/a> on WordPress.org. Our free version has basic support for the free version of Advanced Custom Fields.<br \\/>\\nThe ACF Theme Code Plugin was created by:<br \\/>\\nAaron &amp; Ben, two WordPress developers based in Melbourne, Australia.<\\/p>\\n<p>[plugin_authors_block]<\\/p>\\n","changelog":"<p>2.3.0<\\/p>\\n<ul>\\n<li>New Field Supported: ACF Ninja Forms add on<\\/li>\\n<li>New Field Supported: ACF Gravity Forms add on<\\/li>\\n<li>New Field Supported: ACF RGBA Colour picker<\\/li>\\n<li>New Field(s) Supported: ACF qTranslate<\\/li>\\n<li>Core: Resolved EDD Conflicts<\\/li>\\n<li>Core: Improved Widget Location Variables<\\/li>\\n<li>Fix: EDD naming conflict<\\/li>\\n<li>Fix: Location error if visual editor is disabled<\\/li>\\n<li>Fix: Select Conflict with Seamless Field Group Option<\\/li>\\n<\\/ul>\\n<p>2.2.0<\\/p>\\n<ul>\\n<li>New Field Supported: Button Field found in ACF Pro v5.6.3<\\/li>\\n<li>New Field Supported: Range Field found in ACF Pro v5.6.2<\\/li>\\n<li>Core: Copy All Feature Added<\\/li>\\n<\\/ul>\\n<p>2.1.0<\\/p>\\n<ul>\\n<li>New Field Supported: Group Field found in ACF Pro v5.6<\\/li>\\n<li>New Field Supported: Link Field found in ACF Pro v5.6<\\/li>\\n<li>New Field Supported: Range Field (Third Party)<\\/li>\\n<li>New Field Supported: Focal Point Field (Third Party)<\\/li>\\n<li>Field: Code field improved to escape output by default<\\/li>\\n<li>Field: Google Map field improved to return lat, lng &amp;\\u00a0address<\\/li>\\n<li>Core: resolved an issue with legacy PHP versions<\\/li>\\n<li>Fix: Bug in File field PHP when returned as a URL<\\/li>\\n<\\/ul>\\n<p>2.0.0<\\/p>\\n<ul>\\n<li>Core : Theme Code Pro now generates code based on your location rules!<\\/li>\\n<li>Core : Theme Code Pro now supports all official ACF Add ons!<\\/li>\\n<li>Core : Theme Code Pro now works when ACF Pro is included in a theme!<\\/li>\\n<li>Location Supported : Options Page<\\/li>\\n<li>Location Supported : Widget<\\/li>\\n<li>Location Supported : Comment<\\/li>\\n<li>Location Supported : Taxonomy Term<\\/li>\\n<li>Location Supported : User<\\/li>\\n<li>Location Supported : Attachment<\\/li>\\n<li>Add-on supported : Options Page<\\/li>\\n<li>Add on supported : Repeater Field<\\/li>\\n<li>Add on supported : Gallery Field<\\/li>\\n<li>Add on supported : Flexible Content Field<\\/li>\\n<li>Fix : Minor bug in file field example link markup<\\/li>\\n<li>Fix : Support for Quicklinks feature within locations<\\/li>\\n<\\/ul>\\n<p>1.2.0<\\/p>\\n<ul>\\n<li>Field : Clone - major improvements to the clone field code output<\\/li>\\n<li>New Field Supported : Address Field<\\/li>\\n<li>New Field Supported : Number Slider Field<\\/li>\\n<li>New Field Supported : Post Type Select Field<\\/li>\\n<li>New Field Supported : Code Field<\\/li>\\n<li>New Field Supported : Link Field<\\/li>\\n<li>New Field Supported : Link Picker Field<\\/li>\\n<li>New Field Supported : YouTube Picker Field<\\/li>\\n<li>Core : Special characters now removed from variable names<\\/li>\\n<li>Fix : Compatibility with CPTUI Pro Plugin<\\/li>\\n<\\/ul>\\n<p>1.1.0<\\/p>\\n<ul>\\n<li>Core: Quicklinks feature with anchor links to the relevant theme code block<\\/li>\\n<li>Core: Notice updates &amp; various bug fixes<\\/li>\\n<li>Core: Plugin options screen moved under Settings<\\/li>\\n<\\/ul>\\n<p>1.0.3<\\/p>\\n<ul>\\n<li>Fix: Use the_sub_field method for nested File fields with return format URL<\\/li>\\n<\\/ul>\\n<p>1.0.2<\\/p>\\n<ul>\\n<li>Field: Fix for Post Object when using ACF 4<\\/li>\\n<li>Core: Various internal code improvements<\\/li>\\n<\\/ul>\\n"},"banners":{"high":"","low":""}}";}', 'yes') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=291 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(2, 3, '_wp_page_template', 'default'),
(6, 6, '_edit_last', '1'),
(7, 6, '_edit_lock', '1531756372:1'),
(8, 6, '_wp_page_template', 'page-home.php'),
(9, 1, '_wp_trash_meta_status', 'publish'),
(10, 1, '_wp_trash_meta_time', '1531756543'),
(11, 1, '_wp_desired_post_slug', 'hello-world'),
(12, 1, '_wp_trash_meta_comments_status', 'a:1:{i:1;s:1:"1";}'),
(13, 10, '_edit_last', '1'),
(14, 10, '_edit_lock', '1532921457:1'),
(15, 10, '_wp_page_template', 'default'),
(16, 12, '_edit_last', '1'),
(17, 12, '_wp_page_template', 'default'),
(18, 12, '_edit_lock', '1532921465:1'),
(22, 16, '_edit_last', '1'),
(23, 16, '_wp_page_template', 'default'),
(24, 16, '_edit_lock', '1532921488:1'),
(25, 18, '_edit_last', '1'),
(26, 18, '_wp_page_template', 'page-team.php'),
(27, 18, '_edit_lock', '1533156901:1'),
(28, 20, '_edit_last', '1'),
(29, 20, '_wp_page_template', 'page-bio.php'),
(30, 20, '_edit_lock', '1533162204:1'),
(31, 22, '_menu_item_type', 'post_type'),
(32, 22, '_menu_item_menu_item_parent', '0'),
(33, 22, '_menu_item_object_id', '6'),
(34, 22, '_menu_item_object', 'page'),
(35, 22, '_menu_item_target', ''),
(36, 22, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(37, 22, '_menu_item_xfn', ''),
(38, 22, '_menu_item_url', ''),
(40, 23, '_menu_item_type', 'post_type'),
(41, 23, '_menu_item_menu_item_parent', '0'),
(42, 23, '_menu_item_object_id', '10'),
(43, 23, '_menu_item_object', 'page'),
(44, 23, '_menu_item_target', ''),
(45, 23, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(46, 23, '_menu_item_xfn', ''),
(47, 23, '_menu_item_url', ''),
(49, 24, '_menu_item_type', 'post_type'),
(50, 24, '_menu_item_menu_item_parent', '0'),
(51, 24, '_menu_item_object_id', '16'),
(52, 24, '_menu_item_object', 'page'),
(53, 24, '_menu_item_target', ''),
(54, 24, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(55, 24, '_menu_item_xfn', ''),
(56, 24, '_menu_item_url', ''),
(58, 25, '_menu_item_type', 'post_type'),
(59, 25, '_menu_item_menu_item_parent', '0'),
(60, 25, '_menu_item_object_id', '6'),
(61, 25, '_menu_item_object', 'page'),
(62, 25, '_menu_item_target', ''),
(63, 25, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(64, 25, '_menu_item_xfn', ''),
(65, 25, '_menu_item_url', ''),
(66, 25, '_menu_item_orphaned', '1532921660'),
(67, 26, '_menu_item_type', 'post_type'),
(68, 26, '_menu_item_menu_item_parent', '38'),
(69, 26, '_menu_item_object_id', '18'),
(70, 26, '_menu_item_object', 'page'),
(71, 26, '_menu_item_target', ''),
(72, 26, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(73, 26, '_menu_item_xfn', ''),
(74, 26, '_menu_item_url', ''),
(76, 27, '_menu_item_type', 'post_type'),
(77, 27, '_menu_item_menu_item_parent', '38'),
(78, 27, '_menu_item_object_id', '20'),
(79, 27, '_menu_item_object', 'page'),
(80, 27, '_menu_item_target', ''),
(81, 27, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(82, 27, '_menu_item_xfn', ''),
(83, 27, '_menu_item_url', ''),
(85, 28, '_menu_item_type', 'post_type'),
(86, 28, '_menu_item_menu_item_parent', '0'),
(87, 28, '_menu_item_object_id', '12'),
(88, 28, '_menu_item_object', 'page'),
(89, 28, '_menu_item_target', ''),
(90, 28, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(91, 28, '_menu_item_xfn', ''),
(92, 28, '_menu_item_url', ''),
(103, 30, '_menu_item_type', 'custom'),
(104, 30, '_menu_item_menu_item_parent', '0'),
(105, 30, '_menu_item_object_id', '30'),
(106, 30, '_menu_item_object', 'custom'),
(107, 30, '_menu_item_target', ''),
(108, 30, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(109, 30, '_menu_item_xfn', ''),
(110, 30, '_menu_item_url', ''),
(112, 31, '_edit_last', '1'),
(113, 31, '_wp_page_template', 'default'),
(114, 31, '_edit_lock', '1533075734:1'),
(115, 33, '_edit_last', '1'),
(116, 33, '_wp_page_template', 'default'),
(117, 33, '_edit_lock', '1532921618:1'),
(118, 35, '_menu_item_type', 'custom'),
(119, 35, '_menu_item_menu_item_parent', '0'),
(120, 35, '_menu_item_object_id', '35'),
(121, 35, '_menu_item_object', 'custom'),
(122, 35, '_menu_item_target', ''),
(123, 35, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(124, 35, '_menu_item_xfn', ''),
(125, 35, '_menu_item_url', ''),
(127, 36, '_menu_item_type', 'post_type'),
(128, 36, '_menu_item_menu_item_parent', '35'),
(129, 36, '_menu_item_object_id', '33'),
(130, 36, '_menu_item_object', 'page'),
(131, 36, '_menu_item_target', ''),
(132, 36, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(133, 36, '_menu_item_xfn', ''),
(134, 36, '_menu_item_url', ''),
(136, 37, '_menu_item_type', 'post_type'),
(137, 37, '_menu_item_menu_item_parent', '35'),
(138, 37, '_menu_item_object_id', '31'),
(139, 37, '_menu_item_object', 'page'),
(140, 37, '_menu_item_target', ''),
(141, 37, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(142, 37, '_menu_item_xfn', ''),
(143, 37, '_menu_item_url', ''),
(145, 38, '_menu_item_type', 'custom'),
(146, 38, '_menu_item_menu_item_parent', '0'),
(147, 38, '_menu_item_object_id', '38'),
(148, 38, '_menu_item_object', 'custom'),
(149, 38, '_menu_item_target', ''),
(150, 38, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(151, 38, '_menu_item_xfn', ''),
(152, 38, '_menu_item_url', ''),
(157, 39, '_edit_last', '1'),
(158, 39, '_wp_page_template', 'default'),
(159, 39, '_edit_lock', '1532923133:1'),
(160, 41, '_menu_item_type', 'post_type'),
(161, 41, '_menu_item_menu_item_parent', '30'),
(162, 41, '_menu_item_object_id', '39'),
(163, 41, '_menu_item_object', 'page'),
(164, 41, '_menu_item_target', ''),
(165, 41, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(166, 41, '_menu_item_xfn', ''),
(167, 41, '_menu_item_url', ''),
(168, 42, '_wp_page_template', 'default'),
(169, 42, '_edit_last', '1'),
(170, 42, '_wp_page_template', 'default'),
(171, 42, '_edit_lock', '1532921580:1'),
(172, 43, '_wp_page_template', 'default'),
(173, 43, '_wp_page_template', 'default'),
(174, 43, '_wp_page_template', 'default'),
(175, 43, '_edit_last', '1'),
(176, 43, '_edit_lock', '1532921580:1'),
(177, 44, '_wp_page_template', 'default'),
(178, 44, '_wp_page_template', 'default'),
(179, 44, '_wp_page_template', 'default'),
(180, 44, '_wp_page_template', 'default'),
(181, 44, '_edit_last', '1'),
(182, 44, '_edit_lock', '1532921580:1'),
(183, 45, '_wp_page_template', 'default'),
(184, 45, '_wp_page_template', 'default'),
(185, 45, '_wp_page_template', 'default'),
(186, 45, '_wp_page_template', 'default'),
(187, 45, '_wp_page_template', 'default'),
(188, 45, '_edit_last', '1'),
(189, 45, '_edit_lock', '1532921580:1'),
(190, 46, '_menu_item_type', 'custom'),
(191, 46, '_menu_item_menu_item_parent', '0'),
(192, 46, '_menu_item_object_id', '46'),
(193, 46, '_menu_item_object', 'custom'),
(194, 46, '_menu_item_target', ''),
(195, 46, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(196, 46, '_menu_item_xfn', ''),
(197, 46, '_menu_item_url', ''),
(199, 47, '_menu_item_type', 'custom'),
(200, 47, '_menu_item_menu_item_parent', '0'),
(201, 47, '_menu_item_object_id', '47'),
(202, 47, '_menu_item_object', 'custom'),
(203, 47, '_menu_item_target', ''),
(204, 47, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(205, 47, '_menu_item_xfn', ''),
(206, 47, '_menu_item_url', ''),
(208, 48, '_menu_item_type', 'custom'),
(209, 48, '_menu_item_menu_item_parent', '0'),
(210, 48, '_menu_item_object_id', '48'),
(211, 48, '_menu_item_object', 'custom'),
(212, 48, '_menu_item_target', ''),
(213, 48, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(214, 48, '_menu_item_xfn', ''),
(215, 48, '_menu_item_url', ''),
(217, 49, '_menu_item_type', 'post_type'),
(218, 49, '_menu_item_menu_item_parent', '47'),
(219, 49, '_menu_item_object_id', '45'),
(220, 49, '_menu_item_object', 'page'),
(221, 49, '_menu_item_target', ''),
(222, 49, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(223, 49, '_menu_item_xfn', ''),
(224, 49, '_menu_item_url', ''),
(226, 50, '_menu_item_type', 'post_type'),
(227, 50, '_menu_item_menu_item_parent', '46'),
(228, 50, '_menu_item_object_id', '43'),
(229, 50, '_menu_item_object', 'page'),
(230, 50, '_menu_item_target', ''),
(231, 50, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(232, 50, '_menu_item_xfn', ''),
(233, 50, '_menu_item_url', ''),
(235, 51, '_menu_item_type', 'post_type') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(236, 51, '_menu_item_menu_item_parent', '46'),
(237, 51, '_menu_item_object_id', '42'),
(238, 51, '_menu_item_object', 'page'),
(239, 51, '_menu_item_target', ''),
(240, 51, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(241, 51, '_menu_item_xfn', ''),
(242, 51, '_menu_item_url', ''),
(244, 52, '_menu_item_type', 'post_type'),
(245, 52, '_menu_item_menu_item_parent', '46'),
(246, 52, '_menu_item_object_id', '31'),
(247, 52, '_menu_item_object', 'page'),
(248, 52, '_menu_item_target', ''),
(249, 52, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(250, 52, '_menu_item_xfn', ''),
(251, 52, '_menu_item_url', ''),
(253, 53, '_menu_item_type', 'post_type'),
(254, 53, '_menu_item_menu_item_parent', '48'),
(255, 53, '_menu_item_object_id', '31'),
(256, 53, '_menu_item_object', 'page'),
(257, 53, '_menu_item_target', ''),
(258, 53, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(259, 53, '_menu_item_xfn', ''),
(260, 53, '_menu_item_url', ''),
(261, 59, '_edit_last', '1'),
(262, 59, '_edit_lock', '1533163307:1'),
(263, 62, '_wp_attached_file', '2018/08/atty-doe.jpg'),
(264, 62, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:501;s:6:"height";i:683;s:4:"file";s:20:"2018/08/atty-doe.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"atty-doe-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"atty-doe-220x300.jpg";s:5:"width";i:220;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(265, 20, 'attorney_position', 'Partner'),
(266, 20, '_attorney_position', 'field_5b621f6ad34a4'),
(267, 20, 'attorney_image', '62'),
(268, 20, '_attorney_image', 'field_5b621f014dbef'),
(269, 63, 'attorney_position', 'Partner'),
(270, 63, '_attorney_position', 'field_5b621f6ad34a4'),
(271, 63, 'attorney_image', '62'),
(272, 63, '_attorney_image', 'field_5b621f014dbef'),
(273, 64, 'attorney_position', 'Partner'),
(274, 64, '_attorney_position', 'field_5b621f6ad34a4'),
(275, 64, 'attorney_image', ''),
(276, 64, '_attorney_image', 'field_5b621f014dbef'),
(277, 65, 'attorney_position', 'Partner'),
(278, 65, '_attorney_position', 'field_5b621f6ad34a4'),
(279, 65, 'attorney_image', '62'),
(280, 65, '_attorney_image', 'field_5b621f014dbef'),
(281, 66, '_edit_last', '1'),
(282, 66, '_edit_lock', '1533162033:1'),
(283, 68, 'attorney_position', 'Partner'),
(284, 68, '_attorney_position', 'field_5b621f6ad34a4'),
(285, 68, 'attorney_image', ''),
(286, 68, '_attorney_image', 'field_5b621f014dbef'),
(287, 69, 'attorney_position', 'Partner'),
(288, 69, '_attorney_position', 'field_5b621f6ad34a4'),
(289, 69, 'attorney_image', '62'),
(290, 69, '_attorney_image', 'field_5b621f014dbef') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2018-07-16 15:50:39', '2018-07-16 15:50:39', 'Welcome to WordPress. This is your first post. Edit or delete it, then start writing!', 'Hello world!', '', 'trash', 'open', 'open', '', 'hello-world__trashed', '', '', '2018-07-16 15:55:43', '2018-07-16 15:55:43', '', 0, 'http://dermer.com/?p=1', 0, 'post', '', 1),
(3, 1, '2018-07-16 15:50:39', '2018-07-16 15:50:39', '<h2>Who we are</h2><p>Our website address is: http://dermer.com.</p><h2>What personal data we collect and why we collect it</h2><h3>Comments</h3><p>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><h3>Media</h3><p>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><h3>Contact forms</h3><h3>Cookies</h3><p>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><p>If you have an account and you log in to this site, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><h3>Embedded content from other websites</h3><p>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><h3>Analytics</h3><h2>Who we share your data with</h2><h2>How long we retain your data</h2><p>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><h2>What rights you have over your data</h2><p>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><h2>Where we send your data</h2><p>Visitor comments may be checked through an automated spam detection service.</p><h2>Your contact information</h2><h2>Additional information</h2><h3>How we protect your data</h3><h3>What data breach procedures we have in place</h3><h3>What third parties we receive data from</h3><h3>What automated decision making and/or profiling we do with user data</h3><h3>Industry regulatory disclosure requirements</h3>', 'Privacy Policy', '', 'draft', 'closed', 'open', '', 'privacy-policy', '', '', '2018-07-16 15:50:39', '2018-07-16 15:50:39', '', 0, 'http://dermer.com/?page_id=3', 0, 'page', '', 0),
(6, 1, '2018-07-16 15:55:11', '2018-07-16 15:55:11', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2018-07-16 15:55:11', '2018-07-16 15:55:11', '', 0, 'http://dermer.com/?page_id=6', 0, 'page', '', 0),
(7, 1, '2018-07-16 15:55:11', '2018-07-16 15:55:11', '', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2018-07-16 15:55:11', '2018-07-16 15:55:11', '', 6, 'http://dermer.com/2018/07/16/6-revision-v1/', 0, 'revision', '', 0),
(8, 1, '2018-07-16 15:55:43', '2018-07-16 15:55:43', 'Welcome to WordPress. This is your first post. Edit or delete it, then start writing!', 'Hello world!', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2018-07-16 15:55:43', '2018-07-16 15:55:43', '', 1, 'http://dermer.com/2018/07/16/1-revision-v1/', 0, 'revision', '', 0),
(9, 1, '2018-07-29 22:03:35', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2018-07-29 22:03:35', '0000-00-00 00:00:00', '', 0, 'http://dermer.com/?p=9', 0, 'post', '', 0),
(10, 1, '2018-07-30 03:33:19', '2018-07-30 03:33:19', '', 'Case Results', '', 'publish', 'closed', 'closed', '', 'case-results', '', '', '2018-07-30 03:33:19', '2018-07-30 03:33:19', '', 0, 'http://dermer.com/?page_id=10', 0, 'page', '', 0),
(11, 1, '2018-07-30 03:33:19', '2018-07-30 03:33:19', '', 'Case Results', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2018-07-30 03:33:19', '2018-07-30 03:33:19', '', 10, 'http://dermer.com/2018/07/30/10-revision-v1/', 0, 'revision', '', 0),
(12, 1, '2018-07-30 03:33:27', '2018-07-30 03:33:27', '', 'Testimonials', '', 'publish', 'closed', 'closed', '', 'testimonials', '', '', '2018-07-30 03:33:27', '2018-07-30 03:33:27', '', 0, 'http://dermer.com/?page_id=12', 0, 'page', '', 0),
(13, 1, '2018-07-30 03:33:27', '2018-07-30 03:33:27', '', 'Testimonials', '', 'inherit', 'closed', 'closed', '', '12-revision-v1', '', '', '2018-07-30 03:33:27', '2018-07-30 03:33:27', '', 12, 'http://dermer.com/2018/07/30/12-revision-v1/', 0, 'revision', '', 0),
(16, 1, '2018-07-30 03:33:42', '2018-07-30 03:33:42', '', 'Contact Us', '', 'publish', 'closed', 'closed', '', 'contact-us', '', '', '2018-07-30 03:33:42', '2018-07-30 03:33:42', '', 0, 'http://dermer.com/?page_id=16', 0, 'page', '', 0),
(17, 1, '2018-07-30 03:33:42', '2018-07-30 03:33:42', '', 'Contact Us', '', 'inherit', 'closed', 'closed', '', '16-revision-v1', '', '', '2018-07-30 03:33:42', '2018-07-30 03:33:42', '', 16, 'http://dermer.com/2018/07/30/16-revision-v1/', 0, 'revision', '', 0),
(18, 1, '2018-07-30 03:33:58', '2018-07-30 03:33:58', '', 'Our Team', '', 'publish', 'closed', 'closed', '', 'our-team', '', '', '2018-08-01 20:49:55', '2018-08-01 20:49:55', '', 0, 'http://dermer.com/?page_id=18', 0, 'page', '', 0),
(19, 1, '2018-07-30 03:33:58', '2018-07-30 03:33:58', '', 'Our Team', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2018-07-30 03:33:58', '2018-07-30 03:33:58', '', 18, 'http://dermer.com/2018/07/30/18-revision-v1/', 0, 'revision', '', 0),
(20, 1, '2018-07-30 03:34:06', '2018-07-30 03:34:06', 'In his employment practice, Adam defended both private and public entities and public officials in various employment-related litigation, including ADA, FMLA, Title VII, ADEA, and Section 1983 claims. Adam routinely assists clients in responding to EEOC charges and resolving such claims to avoid costly litigation.\r\n\r\nAdam’s practice includes litigation arising out of various construction defects, including both personal injury litigation from job site accidents to defending contractors and various trade subcontractors in construction defect cases. Adam’s experience ranges from residential construction to commercial development, such as dormitories and apartments.\r\n\r\nAdam has litigated a variety of medical negligence cases, including nursing homes, health departments, nurses and physicians.\r\n\r\nIn the products liability and premises liability fields, Adam has handled cases involving a variety of consumer products, food products, and mechanical equipment and tools. He has defended several chain restaurants in widely-publicized food-borne outbreak cases in Georgia. In addition to his familiarity with handling widespread outbreaks, Adam has handled numerous food-poisoning-related cases, including cases involving foreign objects found in food to garden-variety complaints associated with consumption of food.\r\n\r\nAdam has been called upon by his clients to give seminars on various topics that are germane to his areas of practice.\r\n\r\nAdam has tried cases in state and federal courts, argued motions in all state appellate courts and in the 11th Circuit Court of Appeals. In addition to his trial work, he has extensive experience in all forms of alternative dispute resolution.\r\n\r\n<h2>Education and Associations</h2>\r\n\r\n<ul>\r\n<li>University of Georgia, B.S., Psychology</li>\r\n<li>Mercer University – Walter F. George School of Law, J.D.</li>\r\n<li>Atlanta Bar Association</li>\r\n<li>Defense Research Institute</li>\r\n<li>Atlanta Lawyers Club</li>\r\n<li>Georgia Defense Lawyers Association</li>\r\n<li>Claims & Litigation Management Alliance</li>\r\n<li>Named Super Lawyer by Georgia Super Lawyer magazine 2008-2013</li>\r\n<li>AV Peer Review Rated by Martindale Hubbell</li>\r\n</ul>\r\n\r\n<h2>Bar Associations</h2>\r\n\r\n<ul>\r\n<li>State Bar of Georgia</li>\r\n<li>Supreme Court of Georgia</li>\r\n<li>Georgia Court of Appeals</li>\r\n<li>U.S. District Court, Northern District of Georgia</li>\r\n<li>U.S. District Court, Middle District of Georgia</li>\r\n<li>U.S. District Court, Southern District of Georgia</li>\r\n</ul>', 'Stephen Dermer', '', 'publish', 'closed', 'closed', '', 'stephen-dermer', '', '', '2018-08-01 22:23:23', '2018-08-01 22:23:23', '', 0, 'http://dermer.com/?page_id=20', 0, 'page', '', 0),
(21, 1, '2018-07-30 03:34:06', '2018-07-30 03:34:06', '', 'Stephen Dermer', '', 'inherit', 'closed', 'closed', '', '20-revision-v1', '', '', '2018-07-30 03:34:06', '2018-07-30 03:34:06', '', 20, 'http://dermer.com/2018/07/30/20-revision-v1/', 0, 'revision', '', 0),
(22, 1, '2018-07-30 03:34:36', '2018-07-30 03:34:36', ' ', '', '', 'publish', 'closed', 'closed', '', '22', '', '', '2018-07-30 21:38:36', '2018-07-30 21:38:36', '', 0, 'http://dermer.com/?p=22', 1, 'nav_menu_item', '', 0),
(23, 1, '2018-07-30 03:34:36', '2018-07-30 03:34:36', ' ', '', '', 'publish', 'closed', 'closed', '', '23', '', '', '2018-07-30 21:38:36', '2018-07-30 21:38:36', '', 0, 'http://dermer.com/?p=23', 10, 'nav_menu_item', '', 0),
(24, 1, '2018-07-30 03:34:36', '2018-07-30 03:34:36', ' ', '', '', 'publish', 'closed', 'closed', '', '24', '', '', '2018-07-30 21:38:36', '2018-07-30 21:38:36', '', 0, 'http://dermer.com/?p=24', 12, 'nav_menu_item', '', 0),
(25, 1, '2018-07-30 03:34:20', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2018-07-30 03:34:20', '0000-00-00 00:00:00', '', 0, 'http://dermer.com/?p=25', 1, 'nav_menu_item', '', 0),
(26, 1, '2018-07-30 03:34:36', '2018-07-30 03:34:36', '', 'View All +', '', 'publish', 'closed', 'closed', '', '26', '', '', '2018-07-30 21:38:36', '2018-07-30 21:38:36', '', 0, 'http://dermer.com/?p=26', 9, 'nav_menu_item', '', 0),
(27, 1, '2018-07-30 03:34:36', '2018-07-30 03:34:36', ' ', '', '', 'publish', 'closed', 'closed', '', '27', '', '', '2018-07-30 21:38:36', '2018-07-30 21:38:36', '', 0, 'http://dermer.com/?p=27', 8, 'nav_menu_item', '', 0),
(28, 1, '2018-07-30 03:34:36', '2018-07-30 03:34:36', ' ', '', '', 'publish', 'closed', 'closed', '', '28', '', '', '2018-07-30 21:38:36', '2018-07-30 21:38:36', '', 0, 'http://dermer.com/?p=28', 11, 'nav_menu_item', '', 0),
(30, 1, '2018-07-30 03:35:11', '2018-07-30 03:35:11', '', 'About Our Firm', '', 'publish', 'closed', 'closed', '', 'about-our-firm', '', '', '2018-07-30 21:38:36', '2018-07-30 21:38:36', '', 0, 'http://dermer.com/?p=30', 2, 'nav_menu_item', '', 0),
(31, 1, '2018-07-30 03:35:22', '2018-07-30 03:35:22', 'Lorem ipsum dolor sit amet, <a>consectetur</a> adipiscing elit. Fusce eros sapien, gravida sit amet faucibus vel, pellentesque fringilla enim. Proin vitae eleifend libero. Pellentesque commodo libero turpis, sed consequat massa dapibus eu. Maecenas nec congue magna. Proin sit amet risus ornare magna consectetur hendrerit id in nisl. Maecenas lobortis leo blandit mauris tempor commodo. Interdum et malesuada fames ac ante ipsum primis in faucibus. Pellentesque vitae diam euismod, maximus nunc ut, consectetur massa. Cras dui lorem, porta at congue at, maximus sit amet ipsum.\r\n\r\naecenas ut luctus diam. Cras interdum auctor sapien, eu pulvinar nibh venenatis sit amet. Nulla a magna in tortor aliquam porttitor. Maecenas id tortor vestibulum libero sodales tincidunt. Integer posuere nunc in justo aliquet, semper rhoncus lorem efficitur. Curabitur viverra quam quis iaculis rhoncus. Vestibulum eget lorem rutrum, laoreet mi non, tempus leo. Cras mi arcu, efficitur nec orci vitae, pellentesque aliquet elit. Praesent pharetra eros diam, ac euismod ex porta a. Integer eu odio et eros pellentesque pharetra at in elit.\r\n<blockquote>Throughout this long process, Adam Appel was in constant contact with me and informed me about what was happening throughout the case. He was a source of confidence and guided me through a very overwhelming situation.</blockquote>\r\nCurabitur ullamcorper dolor at lectus laoreet porta. Vestibulum viverra porta sapien ac tristique. Suspendisse feugiat nulla mi, vitae rutrum ipsum mattis vitae. Etiam ultrices non nisl vitae sollicitudin. In pulvinar dui metus, ac dictum mi fermentum id. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut bibendum, ante eu posuere porttitor, velit sapien dignissim neque, ut cursus eros massa convallis nisi. Sed nec nunc eu dolor maximus elementum at vitae risus.\r\n<h2>Nam convallis ex nec dictum ultrices lorem purus hendrerit ex ultrices sollicitudin massa mauris ut ultrices lorem puruselit.</h2>\r\nOrci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus fermentum libero volutpat metus consectetur, dignissim semper urna maximus. Sed efficitur sem lacus, ac dignissim purus semper sed. Suspendisse nec justo maximus, bibendum felis eu, pulvinar nulla. Aenean a velit rhoncus, bibendum sapien eget, fringilla dolor. Suspendisse finibus tellus nec diam interdum, id iaculis tellus maximus. Etiam suscipit sem et eleifend tristique. Praesent rhoncus ac augue at volutpat. Duis egestas lacus in sapien euismod euismod. Phasellus blandit purus nulla. Mauris felis tellus, accumsan a convallis at, mollis a mauris. Curabitur vel dui tempus, fringilla ante nec, porttitor arcu. Morbi hendrerit, lectus id porttitor tincidunt, arcu ipsum consectetur sem, ac malesuada tortor mauris eget est. Maecenas a nisi turpis.\r\n\r\n<hr />\r\n\r\n<h3>h3 former insurance defense</h3>\r\n<ul>\r\n 	<li>University of Georgia, B.S., Psychology</li>\r\n 	<li>Mercer University – Walter F. George School of Law, J.D.</li>\r\n 	<li>Atlanta Bar Association</li>\r\n 	<li>Defense Research Institute</li>\r\n 	<li>Atlanta Lawyers Club</li>\r\n 	<li>Georgia Defense Lawyers Association</li>\r\n 	<li>Claims &amp; Litigation Management Alliance</li>\r\n 	<li>Named Super Lawyer by Georgia Super Lawyer magazine 2008-2013</li>\r\n 	<li>AV Peer Review Rated by Martindale Hubbell</li>\r\n</ul>\r\n<h3>h3 former insurance defense</h3>\r\n<ol>\r\n 	<li>University of Georgia, B.S., Psychology</li>\r\n 	<li>Mercer University – Walter F. George School of Law, J.D.</li>\r\n 	<li>Atlanta Bar Association</li>\r\n 	<li>Defense Research Institute</li>\r\n 	<li>Atlanta Lawyers Club</li>\r\n 	<li>Georgia Defense Lawyers Association</li>\r\n 	<li>Claims &amp; Litigation Management Alliance</li>\r\n 	<li>Named Super Lawyer by Georgia Super Lawyer magazine 2008-2013</li>\r\n 	<li>AV Peer Review Rated by Martindale Hubbell</li>\r\n</ol>', 'Practice Area', '', 'publish', 'closed', 'closed', '', 'practice-area', '', '', '2018-07-31 20:53:04', '2018-07-31 20:53:04', '', 0, 'http://dermer.com/?page_id=31', 0, 'page', '', 0),
(32, 1, '2018-07-30 03:35:22', '2018-07-30 03:35:22', '', 'Practice Area', '', 'inherit', 'closed', 'closed', '', '31-revision-v1', '', '', '2018-07-30 03:35:22', '2018-07-30 03:35:22', '', 31, 'http://dermer.com/2018/07/30/31-revision-v1/', 0, 'revision', '', 0),
(33, 1, '2018-07-30 03:35:44', '2018-07-30 03:35:44', '', 'Practice Areas', '', 'publish', 'closed', 'closed', '', 'practice-areas', '', '', '2018-07-30 03:35:44', '2018-07-30 03:35:44', '', 0, 'http://dermer.com/?page_id=33', 0, 'page', '', 0),
(34, 1, '2018-07-30 03:35:44', '2018-07-30 03:35:44', '', 'Practice Areas', '', 'inherit', 'closed', 'closed', '', '33-revision-v1', '', '', '2018-07-30 03:35:44', '2018-07-30 03:35:44', '', 33, 'http://dermer.com/2018/07/30/33-revision-v1/', 0, 'revision', '', 0),
(35, 1, '2018-07-30 03:36:44', '2018-07-30 03:36:44', '', 'Practice Areas', '', 'publish', 'closed', 'closed', '', 'practice-areas', '', '', '2018-07-30 21:38:36', '2018-07-30 21:38:36', '', 0, 'http://dermer.com/?p=35', 4, 'nav_menu_item', '', 0),
(36, 1, '2018-07-30 03:36:44', '2018-07-30 03:36:44', '', 'View All +', '', 'publish', 'closed', 'closed', '', 'view-all', '', '', '2018-07-30 21:38:36', '2018-07-30 21:38:36', '', 0, 'http://dermer.com/?p=36', 6, 'nav_menu_item', '', 0),
(37, 1, '2018-07-30 03:36:44', '2018-07-30 03:36:44', ' ', '', '', 'publish', 'closed', 'closed', '', '37', '', '', '2018-07-30 21:38:36', '2018-07-30 21:38:36', '', 0, 'http://dermer.com/?p=37', 5, 'nav_menu_item', '', 0),
(38, 1, '2018-07-30 03:37:47', '2018-07-30 03:37:47', '', 'Our Team', '', 'publish', 'closed', 'closed', '', 'our-team', '', '', '2018-07-30 21:38:36', '2018-07-30 21:38:36', '', 0, 'http://dermer.com/?p=38', 7, 'nav_menu_item', '', 0),
(39, 1, '2018-07-30 04:01:12', '2018-07-30 04:01:12', '', 'Blog', '', 'publish', 'closed', 'closed', '', 'blog', '', '', '2018-07-30 04:01:12', '2018-07-30 04:01:12', '', 0, 'http://dermer.com/?page_id=39', 0, 'page', '', 0),
(40, 1, '2018-07-30 04:01:12', '2018-07-30 04:01:12', '', 'Blog', '', 'inherit', 'closed', 'closed', '', '39-revision-v1', '', '', '2018-07-30 04:01:12', '2018-07-30 04:01:12', '', 39, 'http://dermer.com/2018/07/30/39-revision-v1/', 0, 'revision', '', 0),
(41, 1, '2018-07-30 04:01:26', '2018-07-30 04:01:26', ' ', '', '', 'publish', 'closed', 'closed', '', '41', '', '', '2018-07-30 21:38:36', '2018-07-30 21:38:36', '', 0, 'http://dermer.com/?p=41', 3, 'nav_menu_item', '', 0),
(42, 1, '2018-07-30 21:36:13', '2018-07-30 21:36:13', '', 'Practice Area  Copy', '', 'publish', 'closed', 'closed', '', 'practice-area-copy', '', '', '2018-07-30 21:36:13', '2018-07-30 21:36:13', '', 0, 'http://dermer.com/practice-area-copy/', 0, 'page', '', 0),
(43, 1, '2018-07-30 21:36:16', '2018-07-30 21:36:16', '', 'Practice Area  Copy  Copy', '', 'publish', 'closed', 'closed', '', 'practice-area-copy-copy', '', '', '2018-07-30 21:36:16', '2018-07-30 21:36:16', '', 0, 'http://dermer.com/practice-area-copy-copy/', 0, 'page', '', 0),
(44, 1, '2018-07-30 21:36:18', '2018-07-30 21:36:18', '', 'Practice Area  Copy  Copy  Copy', '', 'publish', 'closed', 'closed', '', 'practice-area-copy-copy-copy', '', '', '2018-07-30 21:36:18', '2018-07-30 21:36:18', '', 0, 'http://dermer.com/practice-area-copy-copy-copy/', 0, 'page', '', 0),
(45, 1, '2018-07-30 21:36:22', '2018-07-30 21:36:22', '', 'Practice Area  Copy  Copy  Copy  Copy', '', 'publish', 'closed', 'closed', '', 'practice-area-copy-copy-copy-copy', '', '', '2018-07-30 21:36:22', '2018-07-30 21:36:22', '', 0, 'http://dermer.com/practice-area-copy-copy-copy-copy/', 0, 'page', '', 0),
(46, 1, '2018-07-30 21:37:54', '2018-07-30 21:37:54', '', 'Practice Areas one', '', 'publish', 'closed', 'closed', '', 'practice-areas-one', '', '', '2018-07-30 21:38:15', '2018-07-30 21:38:15', '', 0, 'http://dermer.com/?p=46', 1, 'nav_menu_item', '', 0),
(47, 1, '2018-07-30 21:37:54', '2018-07-30 21:37:54', '', 'Practice Areas Two', '', 'publish', 'closed', 'closed', '', 'practice-areas-two', '', '', '2018-07-30 21:38:15', '2018-07-30 21:38:15', '', 0, 'http://dermer.com/?p=47', 5, 'nav_menu_item', '', 0),
(48, 1, '2018-07-30 21:37:54', '2018-07-30 21:37:54', '', 'Practice Areas Three', '', 'publish', 'closed', 'closed', '', 'practice-areas-three', '', '', '2018-07-30 21:38:15', '2018-07-30 21:38:15', '', 0, 'http://dermer.com/?p=48', 7, 'nav_menu_item', '', 0),
(49, 1, '2018-07-30 21:37:54', '2018-07-30 21:37:54', ' ', '', '', 'publish', 'closed', 'closed', '', '49', '', '', '2018-07-30 21:38:15', '2018-07-30 21:38:15', '', 0, 'http://dermer.com/?p=49', 6, 'nav_menu_item', '', 0),
(50, 1, '2018-07-30 21:37:54', '2018-07-30 21:37:54', ' ', '', '', 'publish', 'closed', 'closed', '', '50', '', '', '2018-07-30 21:38:15', '2018-07-30 21:38:15', '', 0, 'http://dermer.com/?p=50', 4, 'nav_menu_item', '', 0),
(51, 1, '2018-07-30 21:37:54', '2018-07-30 21:37:54', ' ', '', '', 'publish', 'closed', 'closed', '', '51', '', '', '2018-07-30 21:38:15', '2018-07-30 21:38:15', '', 0, 'http://dermer.com/?p=51', 3, 'nav_menu_item', '', 0),
(52, 1, '2018-07-30 21:37:54', '2018-07-30 21:37:54', ' ', '', '', 'publish', 'closed', 'closed', '', '52', '', '', '2018-07-30 21:38:15', '2018-07-30 21:38:15', '', 0, 'http://dermer.com/?p=52', 2, 'nav_menu_item', '', 0),
(53, 1, '2018-07-30 21:37:54', '2018-07-30 21:37:54', ' ', '', '', 'publish', 'closed', 'closed', '', '53', '', '', '2018-07-30 21:38:15', '2018-07-30 21:38:15', '', 0, 'http://dermer.com/?p=53', 8, 'nav_menu_item', '', 0),
(54, 1, '2018-07-31 20:53:04', '2018-07-31 20:53:04', 'Lorem ipsum dolor sit amet, <a>consectetur</a> adipiscing elit. Fusce eros sapien, gravida sit amet faucibus vel, pellentesque fringilla enim. Proin vitae eleifend libero. Pellentesque commodo libero turpis, sed consequat massa dapibus eu. Maecenas nec congue magna. Proin sit amet risus ornare magna consectetur hendrerit id in nisl. Maecenas lobortis leo blandit mauris tempor commodo. Interdum et malesuada fames ac ante ipsum primis in faucibus. Pellentesque vitae diam euismod, maximus nunc ut, consectetur massa. Cras dui lorem, porta at congue at, maximus sit amet ipsum.\r\n\r\naecenas ut luctus diam. Cras interdum auctor sapien, eu pulvinar nibh venenatis sit amet. Nulla a magna in tortor aliquam porttitor. Maecenas id tortor vestibulum libero sodales tincidunt. Integer posuere nunc in justo aliquet, semper rhoncus lorem efficitur. Curabitur viverra quam quis iaculis rhoncus. Vestibulum eget lorem rutrum, laoreet mi non, tempus leo. Cras mi arcu, efficitur nec orci vitae, pellentesque aliquet elit. Praesent pharetra eros diam, ac euismod ex porta a. Integer eu odio et eros pellentesque pharetra at in elit.\r\n<blockquote>Throughout this long process, Adam Appel was in constant contact with me and informed me about what was happening throughout the case. He was a source of confidence and guided me through a very overwhelming situation.</blockquote>\r\nCurabitur ullamcorper dolor at lectus laoreet porta. Vestibulum viverra porta sapien ac tristique. Suspendisse feugiat nulla mi, vitae rutrum ipsum mattis vitae. Etiam ultrices non nisl vitae sollicitudin. In pulvinar dui metus, ac dictum mi fermentum id. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut bibendum, ante eu posuere porttitor, velit sapien dignissim neque, ut cursus eros massa convallis nisi. Sed nec nunc eu dolor maximus elementum at vitae risus.\r\n<h2>Nam convallis ex nec dictum ultrices lorem purus hendrerit ex ultrices sollicitudin massa mauris ut ultrices lorem puruselit.</h2>\r\nOrci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus fermentum libero volutpat metus consectetur, dignissim semper urna maximus. Sed efficitur sem lacus, ac dignissim purus semper sed. Suspendisse nec justo maximus, bibendum felis eu, pulvinar nulla. Aenean a velit rhoncus, bibendum sapien eget, fringilla dolor. Suspendisse finibus tellus nec diam interdum, id iaculis tellus maximus. Etiam suscipit sem et eleifend tristique. Praesent rhoncus ac augue at volutpat. Duis egestas lacus in sapien euismod euismod. Phasellus blandit purus nulla. Mauris felis tellus, accumsan a convallis at, mollis a mauris. Curabitur vel dui tempus, fringilla ante nec, porttitor arcu. Morbi hendrerit, lectus id porttitor tincidunt, arcu ipsum consectetur sem, ac malesuada tortor mauris eget est. Maecenas a nisi turpis.\r\n\r\n<hr />\r\n\r\n<h3>h3 former insurance defense</h3>\r\n<ul>\r\n 	<li>University of Georgia, B.S., Psychology</li>\r\n 	<li>Mercer University – Walter F. George School of Law, J.D.</li>\r\n 	<li>Atlanta Bar Association</li>\r\n 	<li>Defense Research Institute</li>\r\n 	<li>Atlanta Lawyers Club</li>\r\n 	<li>Georgia Defense Lawyers Association</li>\r\n 	<li>Claims &amp; Litigation Management Alliance</li>\r\n 	<li>Named Super Lawyer by Georgia Super Lawyer magazine 2008-2013</li>\r\n 	<li>AV Peer Review Rated by Martindale Hubbell</li>\r\n</ul>\r\n<h3>h3 former insurance defense</h3>\r\n<ol>\r\n 	<li>University of Georgia, B.S., Psychology</li>\r\n 	<li>Mercer University – Walter F. George School of Law, J.D.</li>\r\n 	<li>Atlanta Bar Association</li>\r\n 	<li>Defense Research Institute</li>\r\n 	<li>Atlanta Lawyers Club</li>\r\n 	<li>Georgia Defense Lawyers Association</li>\r\n 	<li>Claims &amp; Litigation Management Alliance</li>\r\n 	<li>Named Super Lawyer by Georgia Super Lawyer magazine 2008-2013</li>\r\n 	<li>AV Peer Review Rated by Martindale Hubbell</li>\r\n</ol>', 'Practice Area', '', 'inherit', 'closed', 'closed', '', '31-revision-v1', '', '', '2018-07-31 20:53:04', '2018-07-31 20:53:04', '', 31, 'http://dermer.com/2018/07/31/31-revision-v1/', 0, 'revision', '', 0),
(55, 1, '2018-08-01 17:02:38', '2018-08-01 17:02:38', 'In his employment practice, Adam defended both private and public entities and public officials in various employment-related litigation, including ADA, FMLA, Title VII, ADEA, and Section 1983 claims. Adam routinely assists clients in responding to EEOC charges and resolving such claims to avoid costly litigation.\r\n\r\nAdam’s practice includes litigation arising out of various construction defects, including both personal injury litigation from job site accidents to defending contractors and various trade subcontractors in construction defect cases. Adam’s experience ranges from residential construction to commercial development, such as dormitories and apartments.\r\n\r\nAdam has litigated a variety of medical negligence cases, including nursing homes, health departments, nurses and physicians.\r\n\r\nIn the products liability and premises liability fields, Adam has handled cases involving a variety of consumer products, food products, and mechanical equipment and tools. He has defended several chain restaurants in widely-publicized food-borne outbreak cases in Georgia. In addition to his familiarity with handling widespread outbreaks, Adam has handled numerous food-poisoning-related cases, including cases involving foreign objects found in food to garden-variety complaints associated with consumption of food.\r\n\r\nAdam has been called upon by his clients to give seminars on various topics that are germane to his areas of practice.\r\n\r\nAdam has tried cases in state and federal courts, argued motions in all state appellate courts and in the 11th Circuit Court of Appeals. In addition to his trial work, he has extensive experience in all forms of alternative dispute resolution.', 'Stephen Dermer', '', 'inherit', 'closed', 'closed', '', '20-revision-v1', '', '', '2018-08-01 17:02:38', '2018-08-01 17:02:38', '', 20, 'http://dermer.com/2018/08/01/20-revision-v1/', 0, 'revision', '', 0),
(56, 1, '2018-08-01 17:19:09', '2018-08-01 17:19:09', 'In his employment practice, Adam defended both private and public entities and public officials in various employment-related litigation, including ADA, FMLA, Title VII, ADEA, and Section 1983 claims. Adam routinely assists clients in responding to EEOC charges and resolving such claims to avoid costly litigation.\r\n\r\nAdam’s practice includes litigation arising out of various construction defects, including both personal injury litigation from job site accidents to defending contractors and various trade subcontractors in construction defect cases. Adam’s experience ranges from residential construction to commercial development, such as dormitories and apartments.\r\n\r\nAdam has litigated a variety of medical negligence cases, including nursing homes, health departments, nurses and physicians.\r\n\r\nIn the products liability and premises liability fields, Adam has handled cases involving a variety of consumer products, food products, and mechanical equipment and tools. He has defended several chain restaurants in widely-publicized food-borne outbreak cases in Georgia. In addition to his familiarity with handling widespread outbreaks, Adam has handled numerous food-poisoning-related cases, including cases involving foreign objects found in food to garden-variety complaints associated with consumption of food.\r\n\r\nAdam has been called upon by his clients to give seminars on various topics that are germane to his areas of practice.\r\n\r\nAdam has tried cases in state and federal courts, argued motions in all state appellate courts and in the 11th Circuit Court of Appeals. In addition to his trial work, he has extensive experience in all forms of alternative dispute resolution.\r\n\r\n<h2>Education and Associations</h2>', 'Stephen Dermer', '', 'inherit', 'closed', 'closed', '', '20-revision-v1', '', '', '2018-08-01 17:19:09', '2018-08-01 17:19:09', '', 20, 'http://dermer.com/2018/08/01/20-revision-v1/', 0, 'revision', '', 0),
(57, 1, '2018-08-01 17:20:01', '2018-08-01 17:20:01', 'In his employment practice, Adam defended both private and public entities and public officials in various employment-related litigation, including ADA, FMLA, Title VII, ADEA, and Section 1983 claims. Adam routinely assists clients in responding to EEOC charges and resolving such claims to avoid costly litigation.\r\n\r\nAdam’s practice includes litigation arising out of various construction defects, including both personal injury litigation from job site accidents to defending contractors and various trade subcontractors in construction defect cases. Adam’s experience ranges from residential construction to commercial development, such as dormitories and apartments.\r\n\r\nAdam has litigated a variety of medical negligence cases, including nursing homes, health departments, nurses and physicians.\r\n\r\nIn the products liability and premises liability fields, Adam has handled cases involving a variety of consumer products, food products, and mechanical equipment and tools. He has defended several chain restaurants in widely-publicized food-borne outbreak cases in Georgia. In addition to his familiarity with handling widespread outbreaks, Adam has handled numerous food-poisoning-related cases, including cases involving foreign objects found in food to garden-variety complaints associated with consumption of food.\r\n\r\nAdam has been called upon by his clients to give seminars on various topics that are germane to his areas of practice.\r\n\r\nAdam has tried cases in state and federal courts, argued motions in all state appellate courts and in the 11th Circuit Court of Appeals. In addition to his trial work, he has extensive experience in all forms of alternative dispute resolution.\r\n\r\n<h2>Education and Associations</h2>\r\n\r\n<ul>\r\n<li>University of Georgia, B.S., Psychology</li>\r\n<li>Mercer University – Walter F. George School of Law, J.D.</li>\r\n<li>Atlanta Bar Association</li>\r\n<li>Defense Research Institute</li>\r\n<li>Atlanta Lawyers Club</li>\r\n<li>Georgia Defense Lawyers Association</li>\r\n<li>Claims & Litigation Management Alliance</li>\r\n<li>Named Super Lawyer by Georgia Super Lawyer magazine 2008-2013</li>\r\n<li>AV Peer Review Rated by Martindale Hubbell</li>\r\n</ul>', 'Stephen Dermer', '', 'inherit', 'closed', 'closed', '', '20-revision-v1', '', '', '2018-08-01 17:20:01', '2018-08-01 17:20:01', '', 20, 'http://dermer.com/2018/08/01/20-revision-v1/', 0, 'revision', '', 0),
(58, 1, '2018-08-01 17:22:11', '2018-08-01 17:22:11', 'In his employment practice, Adam defended both private and public entities and public officials in various employment-related litigation, including ADA, FMLA, Title VII, ADEA, and Section 1983 claims. Adam routinely assists clients in responding to EEOC charges and resolving such claims to avoid costly litigation.\r\n\r\nAdam’s practice includes litigation arising out of various construction defects, including both personal injury litigation from job site accidents to defending contractors and various trade subcontractors in construction defect cases. Adam’s experience ranges from residential construction to commercial development, such as dormitories and apartments.\r\n\r\nAdam has litigated a variety of medical negligence cases, including nursing homes, health departments, nurses and physicians.\r\n\r\nIn the products liability and premises liability fields, Adam has handled cases involving a variety of consumer products, food products, and mechanical equipment and tools. He has defended several chain restaurants in widely-publicized food-borne outbreak cases in Georgia. In addition to his familiarity with handling widespread outbreaks, Adam has handled numerous food-poisoning-related cases, including cases involving foreign objects found in food to garden-variety complaints associated with consumption of food.\r\n\r\nAdam has been called upon by his clients to give seminars on various topics that are germane to his areas of practice.\r\n\r\nAdam has tried cases in state and federal courts, argued motions in all state appellate courts and in the 11th Circuit Court of Appeals. In addition to his trial work, he has extensive experience in all forms of alternative dispute resolution.\r\n\r\n<h2>Education and Associations</h2>\r\n\r\n<ul>\r\n<li>University of Georgia, B.S., Psychology</li>\r\n<li>Mercer University – Walter F. George School of Law, J.D.</li>\r\n<li>Atlanta Bar Association</li>\r\n<li>Defense Research Institute</li>\r\n<li>Atlanta Lawyers Club</li>\r\n<li>Georgia Defense Lawyers Association</li>\r\n<li>Claims & Litigation Management Alliance</li>\r\n<li>Named Super Lawyer by Georgia Super Lawyer magazine 2008-2013</li>\r\n<li>AV Peer Review Rated by Martindale Hubbell</li>\r\n</ul>\r\n\r\n<h2>Bar Associations</h2>\r\n\r\n<ul>\r\n<li>State Bar of Georgia</li>\r\n<li>Supreme Court of Georgia</li>\r\n<li>Georgia Court of Appeals</li>\r\n<li>U.S. District Court, Northern District of Georgia</li>\r\n<li>U.S. District Court, Middle District of Georgia</li>\r\n<li>U.S. District Court, Southern District of Georgia</li>\r\n</ul>', 'Stephen Dermer', '', 'inherit', 'closed', 'closed', '', '20-revision-v1', '', '', '2018-08-01 17:22:11', '2018-08-01 17:22:11', '', 20, 'http://dermer.com/2018/08/01/20-revision-v1/', 0, 'revision', '', 0),
(59, 1, '2018-08-01 21:00:23', '2018-08-01 21:00:23', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"page_template";s:8:"operator";s:2:"==";s:5:"value";s:12:"page-bio.php";}}}s:8:"position";s:15:"acf_after_title";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";a:4:{i:0;s:7:"excerpt";i:1;s:14:"featured_image";i:2;s:10:"categories";i:3;s:4:"tags";}s:11:"description";s:0:"";}', 'Attorney Bio', 'attorney-bio', 'publish', 'closed', 'closed', '', 'group_5b621efc46dac', '', '', '2018-08-01 21:00:41', '2018-08-01 21:00:41', '', 0, 'http://dermer.com/?post_type=acf-field-group&#038;p=59', 0, 'acf-field-group', '', 0),
(60, 1, '2018-08-01 21:00:23', '2018-08-01 21:00:23', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:52:"Image needs to be 501px wide by 683px high and a jpg";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:4:"full";s:7:"library";s:3:"all";s:9:"min_width";i:500;s:10:"min_height";i:682;s:8:"min_size";s:0:"";s:9:"max_width";i:502;s:10:"max_height";i:684;s:8:"max_size";s:0:"";s:10:"mime_types";s:3:"jpg";}', 'Attorney Image', 'attorney_image', 'publish', 'closed', 'closed', '', 'field_5b621f014dbef', '', '', '2018-08-01 21:00:41', '2018-08-01 21:00:41', '', 59, 'http://dermer.com/?post_type=acf-field&#038;p=60', 1, 'acf-field', '', 0),
(61, 1, '2018-08-01 21:00:41', '2018-08-01 21:00:41', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Attorney Position', 'attorney_position', 'publish', 'closed', 'closed', '', 'field_5b621f6ad34a4', '', '', '2018-08-01 21:00:41', '2018-08-01 21:00:41', '', 59, 'http://dermer.com/?post_type=acf-field&p=61', 0, 'acf-field', '', 0),
(62, 1, '2018-08-01 21:01:49', '2018-08-01 21:01:49', '', 'atty-doe', '', 'inherit', 'open', 'closed', '', 'atty-doe', '', '', '2018-08-01 21:01:49', '2018-08-01 21:01:49', '', 20, 'http://dermer.com/wp-content/uploads/2018/08/atty-doe.jpg', 0, 'attachment', 'image/jpeg', 0),
(63, 1, '2018-08-01 21:01:57', '2018-08-01 21:01:57', 'In his employment practice, Adam defended both private and public entities and public officials in various employment-related litigation, including ADA, FMLA, Title VII, ADEA, and Section 1983 claims. Adam routinely assists clients in responding to EEOC charges and resolving such claims to avoid costly litigation.\r\n\r\nAdam’s practice includes litigation arising out of various construction defects, including both personal injury litigation from job site accidents to defending contractors and various trade subcontractors in construction defect cases. Adam’s experience ranges from residential construction to commercial development, such as dormitories and apartments.\r\n\r\nAdam has litigated a variety of medical negligence cases, including nursing homes, health departments, nurses and physicians.\r\n\r\nIn the products liability and premises liability fields, Adam has handled cases involving a variety of consumer products, food products, and mechanical equipment and tools. He has defended several chain restaurants in widely-publicized food-borne outbreak cases in Georgia. In addition to his familiarity with handling widespread outbreaks, Adam has handled numerous food-poisoning-related cases, including cases involving foreign objects found in food to garden-variety complaints associated with consumption of food.\r\n\r\nAdam has been called upon by his clients to give seminars on various topics that are germane to his areas of practice.\r\n\r\nAdam has tried cases in state and federal courts, argued motions in all state appellate courts and in the 11th Circuit Court of Appeals. In addition to his trial work, he has extensive experience in all forms of alternative dispute resolution.\r\n\r\n<h2>Education and Associations</h2>\r\n\r\n<ul>\r\n<li>University of Georgia, B.S., Psychology</li>\r\n<li>Mercer University – Walter F. George School of Law, J.D.</li>\r\n<li>Atlanta Bar Association</li>\r\n<li>Defense Research Institute</li>\r\n<li>Atlanta Lawyers Club</li>\r\n<li>Georgia Defense Lawyers Association</li>\r\n<li>Claims & Litigation Management Alliance</li>\r\n<li>Named Super Lawyer by Georgia Super Lawyer magazine 2008-2013</li>\r\n<li>AV Peer Review Rated by Martindale Hubbell</li>\r\n</ul>\r\n\r\n<h2>Bar Associations</h2>\r\n\r\n<ul>\r\n<li>State Bar of Georgia</li>\r\n<li>Supreme Court of Georgia</li>\r\n<li>Georgia Court of Appeals</li>\r\n<li>U.S. District Court, Northern District of Georgia</li>\r\n<li>U.S. District Court, Middle District of Georgia</li>\r\n<li>U.S. District Court, Southern District of Georgia</li>\r\n</ul>', 'Stephen Dermer', '', 'inherit', 'closed', 'closed', '', '20-revision-v1', '', '', '2018-08-01 21:01:57', '2018-08-01 21:01:57', '', 20, 'http://dermer.com/2018/08/01/20-revision-v1/', 0, 'revision', '', 0),
(64, 1, '2018-08-01 21:23:24', '2018-08-01 21:23:24', 'In his employment practice, Adam defended both private and public entities and public officials in various employment-related litigation, including ADA, FMLA, Title VII, ADEA, and Section 1983 claims. Adam routinely assists clients in responding to EEOC charges and resolving such claims to avoid costly litigation.\r\n\r\nAdam’s practice includes litigation arising out of various construction defects, including both personal injury litigation from job site accidents to defending contractors and various trade subcontractors in construction defect cases. Adam’s experience ranges from residential construction to commercial development, such as dormitories and apartments.\r\n\r\nAdam has litigated a variety of medical negligence cases, including nursing homes, health departments, nurses and physicians.\r\n\r\nIn the products liability and premises liability fields, Adam has handled cases involving a variety of consumer products, food products, and mechanical equipment and tools. He has defended several chain restaurants in widely-publicized food-borne outbreak cases in Georgia. In addition to his familiarity with handling widespread outbreaks, Adam has handled numerous food-poisoning-related cases, including cases involving foreign objects found in food to garden-variety complaints associated with consumption of food.\r\n\r\nAdam has been called upon by his clients to give seminars on various topics that are germane to his areas of practice.\r\n\r\nAdam has tried cases in state and federal courts, argued motions in all state appellate courts and in the 11th Circuit Court of Appeals. In addition to his trial work, he has extensive experience in all forms of alternative dispute resolution.\r\n\r\n<h2>Education and Associations</h2>\r\n\r\n<ul>\r\n<li>University of Georgia, B.S., Psychology</li>\r\n<li>Mercer University – Walter F. George School of Law, J.D.</li>\r\n<li>Atlanta Bar Association</li>\r\n<li>Defense Research Institute</li>\r\n<li>Atlanta Lawyers Club</li>\r\n<li>Georgia Defense Lawyers Association</li>\r\n<li>Claims & Litigation Management Alliance</li>\r\n<li>Named Super Lawyer by Georgia Super Lawyer magazine 2008-2013</li>\r\n<li>AV Peer Review Rated by Martindale Hubbell</li>\r\n</ul>\r\n\r\n<h2>Bar Associations</h2>\r\n\r\n<ul>\r\n<li>State Bar of Georgia</li>\r\n<li>Supreme Court of Georgia</li>\r\n<li>Georgia Court of Appeals</li>\r\n<li>U.S. District Court, Northern District of Georgia</li>\r\n<li>U.S. District Court, Middle District of Georgia</li>\r\n<li>U.S. District Court, Southern District of Georgia</li>\r\n</ul>', 'Stephen Dermer', '', 'inherit', 'closed', 'closed', '', '20-revision-v1', '', '', '2018-08-01 21:23:24', '2018-08-01 21:23:24', '', 20, 'http://dermer.com/2018/08/01/20-revision-v1/', 0, 'revision', '', 0),
(65, 1, '2018-08-01 21:24:46', '2018-08-01 21:24:46', 'In his employment practice, Adam defended both private and public entities and public officials in various employment-related litigation, including ADA, FMLA, Title VII, ADEA, and Section 1983 claims. Adam routinely assists clients in responding to EEOC charges and resolving such claims to avoid costly litigation.\r\n\r\nAdam’s practice includes litigation arising out of various construction defects, including both personal injury litigation from job site accidents to defending contractors and various trade subcontractors in construction defect cases. Adam’s experience ranges from residential construction to commercial development, such as dormitories and apartments.\r\n\r\nAdam has litigated a variety of medical negligence cases, including nursing homes, health departments, nurses and physicians.\r\n\r\nIn the products liability and premises liability fields, Adam has handled cases involving a variety of consumer products, food products, and mechanical equipment and tools. He has defended several chain restaurants in widely-publicized food-borne outbreak cases in Georgia. In addition to his familiarity with handling widespread outbreaks, Adam has handled numerous food-poisoning-related cases, including cases involving foreign objects found in food to garden-variety complaints associated with consumption of food.\r\n\r\nAdam has been called upon by his clients to give seminars on various topics that are germane to his areas of practice.\r\n\r\nAdam has tried cases in state and federal courts, argued motions in all state appellate courts and in the 11th Circuit Court of Appeals. In addition to his trial work, he has extensive experience in all forms of alternative dispute resolution.\r\n\r\n<h2>Education and Associations</h2>\r\n\r\n<ul>\r\n<li>University of Georgia, B.S., Psychology</li>\r\n<li>Mercer University – Walter F. George School of Law, J.D.</li>\r\n<li>Atlanta Bar Association</li>\r\n<li>Defense Research Institute</li>\r\n<li>Atlanta Lawyers Club</li>\r\n<li>Georgia Defense Lawyers Association</li>\r\n<li>Claims & Litigation Management Alliance</li>\r\n<li>Named Super Lawyer by Georgia Super Lawyer magazine 2008-2013</li>\r\n<li>AV Peer Review Rated by Martindale Hubbell</li>\r\n</ul>\r\n\r\n<h2>Bar Associations</h2>\r\n\r\n<ul>\r\n<li>State Bar of Georgia</li>\r\n<li>Supreme Court of Georgia</li>\r\n<li>Georgia Court of Appeals</li>\r\n<li>U.S. District Court, Northern District of Georgia</li>\r\n<li>U.S. District Court, Middle District of Georgia</li>\r\n<li>U.S. District Court, Southern District of Georgia</li>\r\n</ul>', 'Stephen Dermer', '', 'inherit', 'closed', 'closed', '', '20-revision-v1', '', '', '2018-08-01 21:24:46', '2018-08-01 21:24:46', '', 20, 'http://dermer.com/2018/08/01/20-revision-v1/', 0, 'revision', '', 0),
(66, 1, '2018-08-01 21:43:46', '2018-08-01 21:43:46', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"page_template";s:8:"operator";s:2:"==";s:5:"value";s:13:"page-team.php";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";a:5:{i:0;s:11:"the_content";i:1;s:7:"excerpt";i:2;s:14:"featured_image";i:3;s:10:"categories";i:4;s:4:"tags";}s:11:"description";s:0:"";}', 'Attorney Directory', 'attorney-directory', 'publish', 'closed', 'closed', '', 'group_5b62270e01aef', '', '', '2018-08-01 21:43:46', '2018-08-01 21:43:46', '', 0, 'http://dermer.com/?post_type=acf-field-group&#038;p=66', 0, 'acf-field-group', '', 0),
(67, 1, '2018-08-01 21:43:46', '2018-08-01 21:43:46', 'a:12:{s:4:"type";s:12:"relationship";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"post_type";a:1:{i:0;s:4:"page";}s:8:"taxonomy";a:0:{}s:7:"filters";a:1:{i:0;s:6:"search";}s:8:"elements";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:13:"return_format";s:6:"object";}', 'Attorneys', 'attorneys', 'publish', 'closed', 'closed', '', 'field_5b62271574178', '', '', '2018-08-01 21:43:46', '2018-08-01 21:43:46', '', 66, 'http://dermer.com/?post_type=acf-field&p=67', 0, 'acf-field', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(68, 1, '2018-08-01 22:23:09', '2018-08-01 22:23:09', 'In his employment practice, Adam defended both private and public entities and public officials in various employment-related litigation, including ADA, FMLA, Title VII, ADEA, and Section 1983 claims. Adam routinely assists clients in responding to EEOC charges and resolving such claims to avoid costly litigation.\r\n\r\nAdam’s practice includes litigation arising out of various construction defects, including both personal injury litigation from job site accidents to defending contractors and various trade subcontractors in construction defect cases. Adam’s experience ranges from residential construction to commercial development, such as dormitories and apartments.\r\n\r\nAdam has litigated a variety of medical negligence cases, including nursing homes, health departments, nurses and physicians.\r\n\r\nIn the products liability and premises liability fields, Adam has handled cases involving a variety of consumer products, food products, and mechanical equipment and tools. He has defended several chain restaurants in widely-publicized food-borne outbreak cases in Georgia. In addition to his familiarity with handling widespread outbreaks, Adam has handled numerous food-poisoning-related cases, including cases involving foreign objects found in food to garden-variety complaints associated with consumption of food.\r\n\r\nAdam has been called upon by his clients to give seminars on various topics that are germane to his areas of practice.\r\n\r\nAdam has tried cases in state and federal courts, argued motions in all state appellate courts and in the 11th Circuit Court of Appeals. In addition to his trial work, he has extensive experience in all forms of alternative dispute resolution.\r\n\r\n<h2>Education and Associations</h2>\r\n\r\n<ul>\r\n<li>University of Georgia, B.S., Psychology</li>\r\n<li>Mercer University – Walter F. George School of Law, J.D.</li>\r\n<li>Atlanta Bar Association</li>\r\n<li>Defense Research Institute</li>\r\n<li>Atlanta Lawyers Club</li>\r\n<li>Georgia Defense Lawyers Association</li>\r\n<li>Claims & Litigation Management Alliance</li>\r\n<li>Named Super Lawyer by Georgia Super Lawyer magazine 2008-2013</li>\r\n<li>AV Peer Review Rated by Martindale Hubbell</li>\r\n</ul>\r\n\r\n<h2>Bar Associations</h2>\r\n\r\n<ul>\r\n<li>State Bar of Georgia</li>\r\n<li>Supreme Court of Georgia</li>\r\n<li>Georgia Court of Appeals</li>\r\n<li>U.S. District Court, Northern District of Georgia</li>\r\n<li>U.S. District Court, Middle District of Georgia</li>\r\n<li>U.S. District Court, Southern District of Georgia</li>\r\n</ul>', 'Stephen Dermer', '', 'inherit', 'closed', 'closed', '', '20-revision-v1', '', '', '2018-08-01 22:23:09', '2018-08-01 22:23:09', '', 20, 'http://dermer.com/2018/08/01/20-revision-v1/', 0, 'revision', '', 0),
(69, 1, '2018-08-01 22:23:23', '2018-08-01 22:23:23', 'In his employment practice, Adam defended both private and public entities and public officials in various employment-related litigation, including ADA, FMLA, Title VII, ADEA, and Section 1983 claims. Adam routinely assists clients in responding to EEOC charges and resolving such claims to avoid costly litigation.\r\n\r\nAdam’s practice includes litigation arising out of various construction defects, including both personal injury litigation from job site accidents to defending contractors and various trade subcontractors in construction defect cases. Adam’s experience ranges from residential construction to commercial development, such as dormitories and apartments.\r\n\r\nAdam has litigated a variety of medical negligence cases, including nursing homes, health departments, nurses and physicians.\r\n\r\nIn the products liability and premises liability fields, Adam has handled cases involving a variety of consumer products, food products, and mechanical equipment and tools. He has defended several chain restaurants in widely-publicized food-borne outbreak cases in Georgia. In addition to his familiarity with handling widespread outbreaks, Adam has handled numerous food-poisoning-related cases, including cases involving foreign objects found in food to garden-variety complaints associated with consumption of food.\r\n\r\nAdam has been called upon by his clients to give seminars on various topics that are germane to his areas of practice.\r\n\r\nAdam has tried cases in state and federal courts, argued motions in all state appellate courts and in the 11th Circuit Court of Appeals. In addition to his trial work, he has extensive experience in all forms of alternative dispute resolution.\r\n\r\n<h2>Education and Associations</h2>\r\n\r\n<ul>\r\n<li>University of Georgia, B.S., Psychology</li>\r\n<li>Mercer University – Walter F. George School of Law, J.D.</li>\r\n<li>Atlanta Bar Association</li>\r\n<li>Defense Research Institute</li>\r\n<li>Atlanta Lawyers Club</li>\r\n<li>Georgia Defense Lawyers Association</li>\r\n<li>Claims & Litigation Management Alliance</li>\r\n<li>Named Super Lawyer by Georgia Super Lawyer magazine 2008-2013</li>\r\n<li>AV Peer Review Rated by Martindale Hubbell</li>\r\n</ul>\r\n\r\n<h2>Bar Associations</h2>\r\n\r\n<ul>\r\n<li>State Bar of Georgia</li>\r\n<li>Supreme Court of Georgia</li>\r\n<li>Georgia Court of Appeals</li>\r\n<li>U.S. District Court, Northern District of Georgia</li>\r\n<li>U.S. District Court, Middle District of Georgia</li>\r\n<li>U.S. District Court, Southern District of Georgia</li>\r\n</ul>', 'Stephen Dermer', '', 'inherit', 'closed', 'closed', '', '20-revision-v1', '', '', '2018-08-01 22:23:23', '2018-08-01 22:23:23', '', 20, 'http://dermer.com/2018/08/01/20-revision-v1/', 0, 'revision', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(22, 2, 0),
(23, 2, 0),
(24, 2, 0),
(26, 2, 0),
(27, 2, 0),
(28, 2, 0),
(30, 2, 0),
(35, 2, 0),
(36, 2, 0),
(37, 2, 0),
(38, 2, 0),
(41, 2, 0),
(46, 3, 0),
(47, 3, 0),
(48, 3, 0),
(49, 3, 0),
(50, 3, 0),
(51, 3, 0),
(52, 3, 0),
(53, 3, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 0),
(2, 2, 'nav_menu', '', 0, 12),
(3, 3, 'nav_menu', '', 0, 8) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_termmeta`
#

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Menu 1', 'menu-1', 0),
(3, 'PA Menu', 'pa-menu', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', '1p21.admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', 'wp496_privacy'),
(15, 1, 'show_welcome_panel', '1'),
(16, 1, 'session_tokens', 'a:1:{s:64:"7b8076613f46cf8f01db445f500b14930df1996dd4614b6ed58c35b24ad06757";a:4:{s:10:"expiration";i:1533329220;s:2:"ip";s:3:"::1";s:2:"ua";s:120:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36";s:5:"login";i:1533156420;}}'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '9'),
(18, 1, 'gform_recent_forms', 'a:1:{i:0;s:1:"1";}'),
(19, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(20, 1, 'metaboxhidden_nav-menus', 'a:1:{i:0;s:12:"add-post_tag";}'),
(21, 1, 'nav_menu_recently_edited', '2'),
(22, 1, 'wp_user-settings', 'editor=html&libraryContent=browse'),
(23, 1, 'wp_user-settings-time', '1533157313') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, '1p21.admin', '$P$BiRrLBE/2xBsGqDTnz39kjki3ZA3aj1', '1p21-admin', 'garrett@1pointinteractive.com', '', '2018-07-16 15:50:39', '', 0, '1p21.admin') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

