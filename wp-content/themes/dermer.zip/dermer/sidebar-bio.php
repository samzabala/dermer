<div class="sidebar_wrapper bio">
	
	
	<div class="sidebar_image_wrapper">
		
		<img src="<?php bloginfo('template_directory');?>/images/atty-doe.jpg"/>
				
	</div><!-- sidebar_image_wrapper -->
	
	
	
	
</div><!-- sidebar_wrapper -->
