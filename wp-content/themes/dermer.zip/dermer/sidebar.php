<div class="sidebar_wrapper">
	
	
	<div class="sidebar_form">
		
		
		<span class="free_case_title">request a free case evaluation</span><!-- free_case_title -->
		
		<?php gravity_form(3, false, false, false, '', true, 224); ?>
		
		<span class="required">Fields Required</span><!-- required -->
		
		
	</div><!-- sidebar_form -->
	
	<div class="sidebar_list">
		
		<?php wp_nav_menu( array( 'container_class' => 'menu-header', 'theme_location' => 'pa_menu' ) ); ?>
		
	</div><!-- sidebar_list -->
	
	
</div><!-- sidebar_wrapper -->


